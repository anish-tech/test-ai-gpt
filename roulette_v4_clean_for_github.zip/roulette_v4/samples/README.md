# Sample Videos

Place recorded roulette wheel videos here for testing.

Supported formats: .mp4, .avi, .mkv, .mov

## Using test mode

    python run.py

Then go to Source → Video File → Browse and select a sample.

## Recording samples

Use OBS or QuickTime to record a browser window showing a roulette wheel.
Crop tightly around the wheel for best detection results.

Recommended:
- 720p or 1080p
- 30 fps
- 10-30 seconds per spin
- Include both spinning and idle phases
