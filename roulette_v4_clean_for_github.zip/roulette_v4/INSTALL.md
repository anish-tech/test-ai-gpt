# Installation (macOS Intel, Sonoma)

## 1. Python

Use Python 3.11 from python.org or Homebrew. The system Python on macOS is too
restricted for PyQt6 + permissions to work cleanly.

    brew install python@3.11

## 2. Virtual environment

    cd roulette_tracker
    /usr/local/bin/python3.11 -m venv .venv
    source .venv/bin/activate
    pip install --upgrade pip wheel

## 3. Dependencies

    pip install -r requirements.txt

If `opencv-python-headless` fails to build, prefer the wheel:

    pip install --only-binary=:all: opencv-python-headless

## 4. Permissions

macOS will block screen capture until you grant Screen Recording permission to
the terminal (or IDE) that launches the app. See `PERMISSIONS.md`.

## 5. Run

    python run.py

## 6. (Optional) OBS Virtual Camera

If you prefer capturing through OBS:

1. Install OBS Studio (Intel build).
2. In OBS, add your browser window as a source.
3. Tools -> Start Virtual Camera.
4. In this app, choose Source -> "OBS Virtual Camera".

This bypasses macOS window-capture quirks at the cost of one extra hop.

## Troubleshooting

- **Black frames**: Screen Recording permission missing. Quit the terminal
  fully (Cmd-Q, not just close window), re-grant, relaunch.
- **High CPU**: Drop target FPS to 20 in Settings, or shrink the capture
  region. See `PERFORMANCE.md`.
- **PyQt6 import error**: `pip install --upgrade --force-reinstall PyQt6`.
- **Camera not found**: macOS hides virtual cameras until the host app
  (OBS) has launched at least once with permission.
