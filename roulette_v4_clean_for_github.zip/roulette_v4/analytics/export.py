"""CSV export for spins and predictions."""
from __future__ import annotations

import csv
from pathlib import Path

from .database import HistoryDB


def export_spins_csv(db: HistoryDB, out: Path, limit: int = 1000) -> int:
    spins = db.recent_spins(limit=limit)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "started_at", "ended_at", "layout", "actual_number", "notes"])
        for s in spins:
            w.writerow([
                s["id"], f"{s['started_at']:.3f}",
                f"{s['ended_at']:.3f}" if s["ended_at"] is not None else "",
                s["layout"],
                "" if s["actual_number"] is None else s["actual_number"],
                s["notes"] or "",
            ])
    return len(spins)


def export_predictions_csv(db: HistoryDB, out: Path, limit_spins: int = 1000) -> int:
    spins = db.recent_spins(limit=limit_spins)
    out.parent.mkdir(parents=True, exist_ok=True)
    rows = 0
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([
            "spin_id", "t_pred", "seconds_to_drop", "landing_number", "landing_index",
            "confidence", "wheel_omega", "ball_omega", "spin_phase", "neighbors",
        ])
        for s in spins:
            preds = db.predictions_for_spin(s["id"])
            for p in preds:
                w.writerow([
                    s["id"], f"{p['t_pred']:.3f}", f"{p['seconds_to_drop']:.3f}",
                    p["landing_number"], p["landing_index"],
                    f"{p['confidence']:.4f}", f"{p['wheel_omega']:.4f}",
                    f"{p['ball_omega']:.4f}", p["spin_phase"],
                    " ".join(str(x) for x in p["neighbors"]),
                ])
                rows += 1
    return rows
