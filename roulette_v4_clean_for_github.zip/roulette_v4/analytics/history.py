"""History recorder: bridges Pipeline results into the database.

Detects spin start/end heuristically and records predictions during active window.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Optional

from core.pipeline import PipelineResult
from .database import HistoryDB

log = logging.getLogger(__name__)


class HistoryRecorder:
    def __init__(self, db: HistoryDB, layout_name: str) -> None:
        self._db = db
        self._layout = layout_name
        self._lock = threading.Lock()
        self._spin_id: Optional[int] = None
        self._last_prediction_at: float = 0.0
        self._start_omega: float = 6.0
        self._end_omega: float = 1.0
        self._cooldown_s: float = 4.0
        self._spin_started_at: float = 0.0
        self._spin_last_active_at: float = 0.0

    def set_layout(self, name: str) -> None:
        with self._lock:
            self._layout = name

    def consume(self, r: PipelineResult) -> None:
        with self._lock:
            now = r.timestamp
            ball_speed = abs(r.ball_omega)

            if self._spin_id is None:
                if ball_speed > self._start_omega:
                    self._spin_id = self._db.start_spin(now, self._layout)
                    self._spin_started_at = now
                    self._spin_last_active_at = now
                    log.info("Spin %d started", self._spin_id)
            else:
                if ball_speed > self._end_omega * 0.8:
                    self._spin_last_active_at = now

                if r.prediction is not None and (now - self._last_prediction_at) > 0.2:
                    p = r.prediction
                    self._db.add_prediction(
                        spin_id=self._spin_id, t_pred=now,
                        seconds_to_drop=p.seconds_to_drop,
                        landing_number=p.landing_number,
                        landing_index=p.landing_index,
                        confidence=p.confidence,
                        wheel_omega=r.wheel_omega,
                        ball_omega=r.ball_omega,
                        spin_phase=p.spin_phase,
                        neighbors=p.neighbors,
                    )
                    self._last_prediction_at = now

                if (now - self._spin_last_active_at) > self._cooldown_s:
                    self._db.end_spin(self._spin_id, now)
                    log.info("Spin %d ended", self._spin_id)
                    self._spin_id = None

    def force_end(self, actual_number: int | None = None, notes: str | None = None) -> None:
        with self._lock:
            if self._spin_id is None:
                return
            self._db.end_spin(self._spin_id, time.monotonic(), actual_number, notes)
            self._spin_id = None

    @property
    def active_spin_id(self) -> Optional[int]:
        with self._lock:
            return self._spin_id
