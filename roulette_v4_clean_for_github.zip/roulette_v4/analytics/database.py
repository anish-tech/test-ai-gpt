"""SQLite-backed history of spins and predictions."""
from __future__ import annotations

import logging
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from config.defaults import DB_FILE

log = logging.getLogger(__name__)


SCHEMA = """
CREATE TABLE IF NOT EXISTS spins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at REAL NOT NULL,
    ended_at REAL,
    layout TEXT NOT NULL,
    actual_number INTEGER,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    spin_id INTEGER NOT NULL,
    t_pred REAL NOT NULL,
    seconds_to_drop REAL NOT NULL,
    landing_number INTEGER NOT NULL,
    landing_index INTEGER NOT NULL,
    confidence REAL NOT NULL,
    wheel_omega REAL NOT NULL,
    ball_omega REAL NOT NULL,
    spin_phase TEXT NOT NULL,
    neighbors TEXT NOT NULL,
    FOREIGN KEY(spin_id) REFERENCES spins(id)
);

CREATE INDEX IF NOT EXISTS idx_predictions_spin ON predictions(spin_id);
CREATE INDEX IF NOT EXISTS idx_spins_started ON spins(started_at);
"""


class HistoryDB:
    def __init__(self, path: Path | None = None) -> None:
        self._path = Path(path) if path else DB_FILE
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self._path), check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    @contextmanager
    def _cur(self) -> Iterator[sqlite3.Cursor]:
        with self._lock:
            cur = self._conn.cursor()
            try:
                yield cur
                self._conn.commit()
            except sqlite3.Error:
                self._conn.rollback()
                raise
            finally:
                cur.close()

    def start_spin(self, started_at: float, layout: str) -> int:
        with self._cur() as cur:
            cur.execute(
                "INSERT INTO spins(started_at, layout) VALUES (?, ?)",
                (started_at, layout),
            )
            return int(cur.lastrowid)

    def end_spin(self, spin_id: int, ended_at: float, actual_number: int | None = None,
                 notes: str | None = None) -> None:
        with self._cur() as cur:
            cur.execute(
                "UPDATE spins SET ended_at=?, actual_number=?, notes=? WHERE id=?",
                (ended_at, actual_number, notes, spin_id),
            )

    def add_prediction(
        self, spin_id: int, t_pred: float, seconds_to_drop: float,
        landing_number: int, landing_index: int, confidence: float,
        wheel_omega: float, ball_omega: float, spin_phase: str,
        neighbors: list[int],
    ) -> None:
        with self._cur() as cur:
            cur.execute(
                """INSERT INTO predictions(
                    spin_id, t_pred, seconds_to_drop, landing_number, landing_index,
                    confidence, wheel_omega, ball_omega, spin_phase, neighbors
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    spin_id, t_pred, seconds_to_drop, landing_number, landing_index,
                    confidence, wheel_omega, ball_omega, spin_phase,
                    ",".join(str(x) for x in neighbors),
                ),
            )

    def recent_spins(self, limit: int = 50) -> list[dict]:
        with self._cur() as cur:
            cur.execute(
                """SELECT id, started_at, ended_at, layout, actual_number, notes
                   FROM spins ORDER BY started_at DESC LIMIT ?""",
                (limit,),
            )
            cols = [c[0] for c in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def predictions_for_spin(self, spin_id: int) -> list[dict]:
        with self._cur() as cur:
            cur.execute(
                """SELECT t_pred, seconds_to_drop, landing_number, landing_index,
                          confidence, wheel_omega, ball_omega, spin_phase, neighbors
                   FROM predictions WHERE spin_id=? ORDER BY t_pred ASC""",
                (spin_id,),
            )
            cols = [c[0] for c in cur.description]
            rows = []
            for row in cur.fetchall():
                d = dict(zip(cols, row))
                d["neighbors"] = [int(x) for x in d["neighbors"].split(",") if x]
                rows.append(d)
            return rows

    def number_frequency(self, limit_spins: int = 200) -> dict[int, int]:
        with self._cur() as cur:
            cur.execute(
                """SELECT actual_number FROM spins
                   WHERE actual_number IS NOT NULL
                   ORDER BY started_at DESC LIMIT ?""",
                (limit_spins,),
            )
            freq: dict[int, int] = {}
            for (n,) in cur.fetchall():
                if n is None:
                    continue
                freq[int(n)] = freq.get(int(n), 0) + 1
            return freq

    def hit_stats(self, limit_spins: int = 200) -> dict:
        spins = self.recent_spins(limit=limit_spins)
        total = exact = within_2 = within_4 = 0
        for s in spins:
            if s["actual_number"] is None:
                continue
            preds = self.predictions_for_spin(s["id"])
            if not preds:
                continue
            relevant = [p for p in preds if p["spin_phase"] in ("spinning", "decaying")]
            if not relevant:
                continue
            last = relevant[-1]
            actual = int(s["actual_number"])
            total += 1
            if actual == last["landing_number"]:
                exact += 1
                within_2 += 1
                within_4 += 1
                continue
            n = last["neighbors"]
            if not n:
                continue
            center_idx = len(n) // 2
            within_2_set = set(n[max(0, center_idx - 2): center_idx + 3])
            within_4_set = set(n)
            if actual in within_2_set:
                within_2 += 1
            if actual in within_4_set:
                within_4 += 1
        return {
            "total": total, "exact": exact,
            "within_2": within_2, "within_4": within_4,
            "exact_rate": (exact / total) if total else 0.0,
            "within_2_rate": (within_2 / total) if total else 0.0,
            "within_4_rate": (within_4 / total) if total else 0.0,
        }

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except sqlite3.Error:
                pass
