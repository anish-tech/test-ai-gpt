"""Analytics and history persistence."""
