"""Wheel detection + motion energy + countdown detector — V4.

Key improvements:
- Focus ROI: crops frame to upper portion to exclude betting table UI
- Better scoring with rounder-circle preference
- Countdown detector: looks for countdown timer text/bar changes
- Cached annulus mask for motion energy (no per-frame allocation)
"""
from __future__ import annotations

import logging
import re
from collections import deque
from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np

log = logging.getLogger(__name__)


@dataclass
class WheelDetection:
    cx: float
    cy: float
    radius: float
    confidence: float


class WheelDetector:
    """Finds the wheel by focusing on the upper portion of the frame
    where the wheel actually is, excluding the betting table below."""

    def __init__(self, redetect_every=90):
        self._history: deque[WheelDetection] = deque(maxlen=30)
        self._redetect = max(1, redetect_every)
        self._idx = 0
        self._locked: Optional[WheelDetection] = None
        self._clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))

    def reset(self):
        self._history.clear(); self._locked = None; self._idx = 0

    def detect(self, frame_bgr, force=False):
        self._idx += 1
        if not force and self._locked and self._idx % self._redetect != 0:
            return self._locked

        h, w = frame_bgr.shape[:2]
        if h < 80 or w < 80:
            return self._locked

        # CRITICAL: Crop to upper 65% of frame to exclude betting table
        # Looking at the screenshot, the wheel occupies the upper portion
        # and the racetrack/numbers are in the lower 35%
        crop_h = int(h * 0.65)
        cropped = frame_bgr[:crop_h, :]

        # Downscale for speed
        ch, cw = cropped.shape[:2]
        scale = min(1.0, 450.0 / max(ch, cw))
        if scale < 1:
            small = cv2.resize(cropped, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        else:
            small = cropped
        sh, sw = small.shape[:2]

        gray = self._clahe.apply(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY))
        gray = cv2.GaussianBlur(gray, (5, 5), 1.5)

        best = self._find_best(gray, small, sh, sw)
        if best is None:
            return self._locked

        # Map back: scale coordinates back to original frame coords (crop offset is 0,0 so just scale)
        cx, cy, r = best[0] / scale, best[1] / scale, best[2] / scale
        det = WheelDetection(cx=cx, cy=cy, radius=r, confidence=0.8)
        self._history.append(det)

        if len(self._history) >= 4:
            cxs = np.array([d.cx for d in self._history])
            cys = np.array([d.cy for d in self._history])
            rs = np.array([d.radius for d in self._history])
            # Outlier rejection
            med_cx, med_cy, med_r = np.median(cxs), np.median(cys), np.median(rs)
            mask = (
                (np.abs(cxs - med_cx) < max(np.std(cxs) * 2.5, 10)) &
                (np.abs(cys - med_cy) < max(np.std(cys) * 2.5, 10)) &
                (np.abs(rs - med_r) < max(np.std(rs) * 2.5, 10))
            )
            if mask.sum() >= 3:
                cxs, cys, rs = cxs[mask], cys[mask], rs[mask]
            self._locked = WheelDetection(
                cx=float(np.median(cxs)), cy=float(np.median(cys)),
                radius=float(np.median(rs)),
                confidence=min(1.0, 0.5 + 0.02 * mask.sum()),
            )
        else:
            self._locked = det
        return self._locked

    def _find_best(self, gray, color, h, w):
        md = min(h, w)
        cands = []
        # Wider range: wheel can be 15-45% of the cropped frame
        for dp, p1, p2, rlo, rhi in [
            (1.2, 100, 42, 0.15, 0.48),
            (1.5, 80, 35, 0.15, 0.48),
            (1.2, 120, 52, 0.20, 0.48),
            (1.0, 65, 28, 0.12, 0.45),
            (1.3, 50, 22, 0.12, 0.48),
            (1.8, 70, 30, 0.18, 0.45),
        ]:
            minr, maxr = int(md * rlo), int(md * rhi)
            if minr >= maxr or minr < 12:
                continue
            circs = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, dp=dp,
                                     minDist=int(md * 0.25), param1=p1, param2=p2,
                                     minRadius=minr, maxRadius=maxr)
            if circs is None:
                continue
            for c in circs[0]:
                sc = self._score(gray, color, float(c[0]), float(c[1]), float(c[2]), h, w)
                cands.append((float(c[0]), float(c[1]), float(c[2]), sc))
        if not cands:
            return None
        cands.sort(key=lambda x: x[3], reverse=True)
        return cands[0][:3] if cands[0][3] > 0.08 else None

    def _score(self, gray, color, cx, cy, r, h, w):
        s = 0.0
        icx, icy = int(cx), int(cy)

        # 1. Rim edge density in the ring (0-0.30)
        mask = np.zeros_like(gray)
        cv2.circle(mask, (icx, icy), int(r * 1.06), 255, -1)
        cv2.circle(mask, (icx, icy), int(r * 0.80), 0, -1)
        edges = cv2.Canny(gray, 50, 140)
        ra = max(1, cv2.countNonZero(mask))
        s += min(0.30, cv2.countNonZero(cv2.bitwise_and(edges, edges, mask=mask)) / ra * 7)

        # 2. Interior has complex texture (wheel pockets, numbers) (0-0.20)
        imask = np.zeros_like(gray)
        cv2.circle(imask, (icx, icy), int(r * 0.75), 255, -1)
        pix = gray[imask > 0]
        if len(pix) > 50:
            s += min(0.20, float(np.std(pix)) / 70.0)

        # 3. Green pockets on rim (0-0.25)
        hsv = cv2.cvtColor(color, cv2.COLOR_BGR2HSV)
        gmask = cv2.inRange(hsv, np.array([35, 30, 30]), np.array([90, 255, 255]))
        gcount = cv2.countNonZero(cv2.bitwise_and(gmask, gmask, mask=mask))
        if gcount > 2:
            s += min(0.25, gcount / 50.0 * 0.25)

        # 4. Red/black alternating pockets (0-0.10)
        rmask = cv2.inRange(hsv, np.array([0, 50, 40]), np.array([12, 255, 255]))
        rmask2 = cv2.inRange(hsv, np.array([168, 50, 40]), np.array([180, 255, 255]))
        if cv2.countNonZero(cv2.bitwise_and(rmask | rmask2, rmask | rmask2, mask=mask)) > 3:
            s += 0.10

        # 5. Prefer circles that are well inside the frame (not clipped) (0-0.10)
        margin = r * 0.2
        if cx - r > margin and cy - r > margin and cx + r < w - margin and cy + r < h - margin:
            s += 0.10

        # 6. Prefer rounder candidates (center not at extreme edges) (0-0.05)
        d = ((cx - w / 2) ** 2 + (cy - h / 2) ** 2) ** 0.5
        s += max(0, 0.05 * (1 - d / ((w ** 2 + h ** 2) ** 0.5 / 2)))

        return s

    @property
    def locked(self):
        return self._locked


class MotionEnergyDetector:
    """Detects spin state from frame-difference energy in wheel annulus.
    Cached annulus mask to avoid per-frame allocation."""

    def __init__(self, threshold=8.0, smooth=0.85):
        self._prev_gray: Optional[np.ndarray] = None
        self._energy = 0.0
        self._threshold = threshold
        self._smooth = smooth
        self._peak_energy = 0.0
        self._energy_history: deque[float] = deque(maxlen=90)
        self._spinning = False
        self._mask_cache: Optional[tuple] = None

    def reset(self):
        self._prev_gray = None; self._energy = 0; self._peak_energy = 0
        self._energy_history.clear(); self._spinning = False; self._mask_cache = None

    def _get_mask(self, h, w, center, radius):
        key = (int(center[0]), int(center[1]), int(radius), h, w)
        if self._mask_cache and self._mask_cache[0] == key:
            return self._mask_cache[1]
        m = np.zeros((h, w), dtype=np.uint8)
        cv2.circle(m, (int(center[0]), int(center[1])), int(radius * 1.05), 255, -1)
        cv2.circle(m, (int(center[0]), int(center[1])), int(radius * 0.25), 0, -1)
        self._mask_cache = (key, m)
        return m

    def update(self, frame_bgr, center, radius):
        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape
        mask = self._get_mask(h, w, center, radius)

        if self._prev_gray is None or self._prev_gray.shape != gray.shape:
            self._prev_gray = gray
            return False, 0.0

        diff = cv2.absdiff(gray, self._prev_gray)
        self._prev_gray = gray
        masked = cv2.bitwise_and(diff, diff, mask=mask)
        npix = max(1, cv2.countNonZero(mask))
        raw = float(np.sum(masked)) / npix
        self._energy = self._smooth * self._energy + (1 - self._smooth) * raw
        self._energy_history.append(self._energy)
        if self._energy > self._peak_energy:
            self._peak_energy = self._energy

        if not self._spinning:
            if self._energy > self._threshold:
                self._spinning = True
        else:
            if self._energy < self._threshold * 0.30:
                self._spinning = False
        return self._spinning, self._energy

    @property
    def energy(self): return self._energy
    @property
    def peak_energy(self): return self._peak_energy
    @property
    def is_spinning(self): return self._spinning
    @property
    def energy_ratio(self):
        return min(1, self._energy / self._peak_energy) if self._peak_energy > 1 else 0


class CountdownDetector:
    """Detects the betting countdown timer from the casino stream.

    Strategy: monitor a region for the countdown bar/text. Casino streams typically
    show a countdown as either:
    1. A shrinking progress bar
    2. A text timer ("PLACE YOUR BETS" → countdown → "NO MORE BETS")

    We detect this by looking for:
    - Color changes in a specific region (the countdown bar is usually colored)
    - Text state changes ("WAIT FOR NEXT GAME" visible in your stream)
    - Rapid brightness/color shifts in the lower UI area

    The detector outputs: betting_open, seconds_remaining (estimate)
    """

    def __init__(self):
        self._state = "unknown"  # "betting_open" | "betting_closed" | "unknown"
        self._prev_bar_ratio = 0.0
        self._bar_ratios: deque[float] = deque(maxlen=30)
        self._state_history: deque[str] = deque(maxlen=10)
        self._frames_in_state = 0
        self._last_open_energy = 0.0

    def reset(self):
        self._state = "unknown"
        self._bar_ratios.clear()
        self._state_history.clear()
        self._frames_in_state = 0

    def update(self, frame_bgr, wheel_center=None, wheel_radius=None):
        """Analyze frame for countdown state.
        Returns (betting_open: bool, seconds_estimate: float, state: str)
        """
        h, w = frame_bgr.shape[:2]

        # Look for "WAIT FOR NEXT GAME" or "NO MORE BETS" or "PLACE YOUR BETS"
        # These are typically in the center area of the stream, overlaid on the wheel
        # Strategy: detect the text banner by looking for a colored bar in the middle

        # Check center region for bright text overlay
        center_strip = frame_bgr[int(h * 0.35):int(h * 0.50), int(w * 0.25):int(w * 0.75)]
        if center_strip.size == 0:
            return True, 0.0, self._state

        # Detect bright text on dark background (common in casino streams)
        gray_strip = cv2.cvtColor(center_strip, cv2.COLOR_BGR2GRAY)
        bright_pixels = np.sum(gray_strip > 200)
        total_pixels = max(1, gray_strip.size)
        text_ratio = bright_pixels / total_pixels

        # Check for colored countdown bar (usually green/yellow/red)
        hsv_strip = cv2.cvtColor(center_strip, cv2.COLOR_BGR2HSV)

        # Green bar (betting open)
        green = cv2.countNonZero(cv2.inRange(hsv_strip, np.array([35, 50, 50]), np.array([85, 255, 255])))
        # Red bar (betting closed / timer low)
        red1 = cv2.countNonZero(cv2.inRange(hsv_strip, np.array([0, 50, 50]), np.array([10, 255, 255])))
        red2 = cv2.countNonZero(cv2.inRange(hsv_strip, np.array([170, 50, 50]), np.array([180, 255, 255])))
        red = red1 + red2

        strip_total = max(1, center_strip.shape[0] * center_strip.shape[1])
        green_ratio = green / strip_total
        red_ratio = red / strip_total

        # Also check for countdown progress bar (usually at bottom of wheel area)
        bar_region = frame_bgr[int(h * 0.52):int(h * 0.58), int(w * 0.20):int(w * 0.80)]
        if bar_region.size > 0:
            bar_hsv = cv2.cvtColor(bar_region, cv2.COLOR_BGR2HSV)
            bar_colored = cv2.countNonZero(
                cv2.inRange(bar_hsv, np.array([0, 40, 80]), np.array([180, 255, 255])))
            bar_ratio = bar_colored / max(1, bar_region.shape[0] * bar_region.shape[1])
            self._bar_ratios.append(bar_ratio)
        else:
            bar_ratio = 0

        # Determine state
        prev_state = self._state

        if text_ratio > 0.05:
            # Significant text visible — likely "WAIT FOR NEXT GAME" or "NO MORE BETS"
            if red_ratio > 0.01 or green_ratio < 0.005:
                self._state = "betting_closed"
            else:
                self._state = "betting_open"
        elif green_ratio > 0.008:
            self._state = "betting_open"
        elif red_ratio > 0.008:
            self._state = "betting_closed"
        else:
            # No clear signals — check if bar is shrinking
            if len(self._bar_ratios) >= 5:
                recent = list(self._bar_ratios)[-5:]
                if recent[-1] < recent[0] * 0.7:
                    self._state = "betting_open"  # countdown is progressing

        if self._state == prev_state:
            self._frames_in_state += 1
        else:
            self._frames_in_state = 0
        self._state_history.append(self._state)

        # Estimate seconds remaining
        secs = 0.0
        if self._state == "betting_open" and len(self._bar_ratios) >= 3:
            # Rough estimate from bar shrinkage rate
            recent = list(self._bar_ratios)
            if len(recent) >= 10:
                rate = (recent[-1] - recent[-10]) / 10.0 if recent[-10] != 0 else 0
                if rate < -0.001:
                    secs = max(0, recent[-1] / abs(rate))
                    secs = min(30, secs)  # cap at 30s

        betting_open = self._state == "betting_open" or self._state == "unknown"
        return betting_open, secs, self._state


class WheelRotationTracker:
    """Polar-transform phase correlation for wheel rotation."""
    def __init__(self, polar_size=180):
        self._sz = polar_size; self._prev = None; self._cum = 0.0

    def reset(self):
        self._prev = None; self._cum = 0.0

    def update(self, frame_bgr, center, radius):
        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        inner_r = radius * 0.70
        if inner_r < 20: return None
        try:
            polar = cv2.warpPolar(
                gray, (self._sz, self._sz), center, inner_r,
                cv2.WARP_FILL_OUTLIERS + cv2.INTER_LINEAR + cv2.WARP_POLAR_LINEAR,
            ).astype(np.float32)
        except cv2.error: return None

        if self._prev is None:
            self._prev = polar; return None
        try:
            (_, dy), resp = cv2.phaseCorrelate(self._prev, polar)
        except cv2.error:
            self._prev = polar; return None
        self._prev = polar
        da = -(dy / self._sz) * 2.0 * np.pi
        if abs(da) > np.pi / 3 or resp < 0.02: return 0.0
        self._cum += da
        return da

    @property
    def cumulative_angle(self): return self._cum
