"""Core capture, tracking, and prediction package."""
