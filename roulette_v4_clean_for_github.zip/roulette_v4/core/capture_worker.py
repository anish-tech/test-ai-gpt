"""Capture thread — grabs frames and pushes to buffer."""
from __future__ import annotations

import logging
import threading
import time
from typing import Optional

from .capture import CaptureSource
from .frame_buffer import Frame, FrameBuffer, FpsMeter

log = logging.getLogger(__name__)


class CaptureWorker:
    def __init__(self, source: CaptureSource, buffer: FrameBuffer, target_fps=30):
        self._source = source
        self._buffer = buffer
        self._target_fps = max(1, target_fps)
        self._period = 1.0 / self._target_fps
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._fps = FpsMeter()
        self._seq = 0

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="Capture", daemon=True)
        self._thread.start()
        log.info("Capture: %s @ %d fps", self._source.description, self._target_fps)

    def stop(self, timeout=2.0):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=timeout)
        try:
            self._source.close()
        except Exception:
            pass
        self._buffer.close()

    def fps(self):
        return self._fps.fps()

    def _run(self):
        fails = 0
        next_t = time.monotonic()
        while not self._stop.is_set():
            frame = self._source.grab()
            if frame is None:
                fails += 1
                if fails > 30:
                    log.error("Capture failing; stopping.")
                    break
                time.sleep(0.02)
                continue
            fails = 0
            self._seq += 1
            self._buffer.push(Frame(image=frame, timestamp=time.monotonic(), seq=self._seq))
            self._fps.tick()

            next_t += self._period
            now = time.monotonic()
            if next_t > now:
                time.sleep(next_t - now)
            elif next_t < now - self._period:
                next_t = now
