"""Kalman filters V4 — tuned for roulette ball tracking.

Key improvements:
- Adaptive process noise: increases during fast motion, decreases when slow
- Measurement gating: reject observations too far from prediction
- Smooth recovery after ball loss
"""
from __future__ import annotations

import math
import numpy as np


class Kalman2D:
    """Constant-velocity 2D Kalman with adaptive noise and gating."""

    def __init__(self, process_var=8.0, measurement_var=4.0, gate_sigma=4.0):
        self.process_var = process_var
        self.measurement_var = measurement_var
        self._gate_sigma = gate_sigma
        self.initialized = False
        self._x = np.zeros(4, dtype=np.float64)
        self._P = np.eye(4, dtype=np.float64) * 1000.0
        self._F = np.eye(4, dtype=np.float64)
        self._H = np.zeros((2, 4), dtype=np.float64)
        self._H[0, 0] = 1.0
        self._H[1, 1] = 1.0
        self._R = np.eye(2, dtype=np.float64) * self.measurement_var
        self._I4 = np.eye(4, dtype=np.float64)
        self._miss_count = 0

    def reset(self):
        self.initialized = False
        self._x[:] = 0.0
        self._P[:] = np.eye(4) * 1000.0
        self._miss_count = 0

    def predict(self, dt):
        if dt <= 0:
            dt = 1 / 30
        self._F[0, 2] = dt
        self._F[1, 3] = dt
        # Adaptive process noise: scale with velocity magnitude
        speed = math.hypot(self._x[2], self._x[3])
        q = self.process_var * max(1.0, speed / 50.0)
        Q = np.array([
            [dt**4/4, 0, dt**3/2, 0],
            [0, dt**4/4, 0, dt**3/2],
            [dt**3/2, 0, dt**2, 0],
            [0, dt**3/2, 0, dt**2],
        ], dtype=np.float64) * q
        self._x = self._F @ self._x
        self._P = self._F @ self._P @ self._F.T + Q
        return float(self._x[0]), float(self._x[1]), float(self._x[2]), float(self._x[3])

    def update(self, mx, my):
        z = np.array([mx, my], dtype=np.float64)
        if not self.initialized:
            self._x[0] = mx; self._x[1] = my
            self._x[2] = 0.0; self._x[3] = 0.0
            self._P = np.eye(4, dtype=np.float64) * 50.0
            self.initialized = True
            self._miss_count = 0
            return True

        # Mahalanobis gating — reject wild observations
        y = z - self._H @ self._x
        S = self._H @ self._P @ self._H.T + self._R
        try:
            S_inv = np.linalg.inv(S)
        except np.linalg.LinAlgError:
            return False
        maha2 = float(y @ S_inv @ y)
        gate = self._gate_sigma ** 2

        # After many misses, widen the gate to allow recovery
        if self._miss_count > 5:
            gate *= 4.0

        if maha2 > gate:
            self._miss_count += 1
            if self._miss_count > 15:
                # Hard reset to new observation
                self._x[0] = mx; self._x[1] = my
                self._x[2] = 0.0; self._x[3] = 0.0
                self._P = np.eye(4, dtype=np.float64) * 200.0
                self._miss_count = 0
                return True
            return False

        K = self._P @ self._H.T @ S_inv
        self._x = self._x + K @ y
        self._P = (self._I4 - K @ self._H) @ self._P
        self._miss_count = 0
        return True

    def miss(self):
        """Call when no observation available — inflates uncertainty."""
        self._miss_count += 1
        self._P *= 1.05  # slowly grow uncertainty

    @property
    def state(self):
        return float(self._x[0]), float(self._x[1]), float(self._x[2]), float(self._x[3])

    @property
    def velocity(self):
        return math.hypot(self._x[2], self._x[3])

    @property
    def position_uncertainty(self):
        return math.sqrt(self._P[0, 0] + self._P[1, 1])


def angle_unwrap(prev, current):
    diff = current - prev
    while diff > math.pi: current -= 2 * math.pi; diff = current - prev
    while diff < -math.pi: current += 2 * math.pi; diff = current - prev
    return current


class AngleKalman:
    """1D angle + angular velocity Kalman."""
    def __init__(self, process_var=1.5, measurement_var=0.02):
        self.process_var = process_var
        self.measurement_var = measurement_var
        self.initialized = False
        self._x = np.zeros(2, dtype=np.float64)
        self._P = np.eye(2, dtype=np.float64) * 1000.0
        self._F = np.eye(2, dtype=np.float64)
        self._H = np.array([[1.0, 0.0]], dtype=np.float64)
        self._R = np.array([[self.measurement_var]])
        self._I2 = np.eye(2, dtype=np.float64)
        self._last_meas = 0.0

    def reset(self):
        self.initialized = False
        self._x[:] = 0; self._P[:] = np.eye(2) * 1000; self._last_meas = 0

    def predict(self, dt):
        if dt <= 0: dt = 1/30
        self._F[0, 1] = dt
        q = self.process_var
        Q = np.array([[dt**3/3, dt**2/2], [dt**2/2, dt]]) * q
        self._x = self._F @ self._x
        self._P = self._F @ self._P @ self._F.T + Q
        return float(self._x[0]), float(self._x[1])

    def update(self, theta_meas):
        if not self.initialized:
            self._x[0] = theta_meas; self._x[1] = 0
            self._P = np.eye(2) * 1.0
            self.initialized = True; self._last_meas = theta_meas
            return
        tu = angle_unwrap(self._last_meas, theta_meas)
        self._last_meas = tu
        tu = angle_unwrap(self._x[0], tu)
        z = np.array([tu])
        y = z - self._H @ self._x
        S = self._H @ self._P @ self._H.T + self._R
        try:
            K = self._P @ self._H.T @ np.linalg.inv(S)
        except np.linalg.LinAlgError:
            return
        self._x = self._x + (K @ y).flatten()
        self._P = (self._I2 - K @ self._H) @ self._P

    @property
    def theta(self): return float(self._x[0])
    @property
    def omega(self): return float(self._x[1])
