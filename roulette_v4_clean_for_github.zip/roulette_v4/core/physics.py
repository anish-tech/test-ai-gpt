"""Physics estimation — V3.

Wider windows, lower thresholds for triggering predictions.
"""
from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class MotionEstimate:
    omega: float = 0.0
    alpha: float = 0.0
    radius: float = 0.0
    radius_rate: float = 0.0
    samples: int = 0


class _SlidingFit:
    def __init__(self, max_samples=60, max_age=3.0):
        self._buf: deque[tuple[float, float]] = deque()
        self._max_samples = max_samples
        self._max_age = max_age

    def push(self, t, value):
        self._buf.append((t, value))
        while len(self._buf) > self._max_samples:
            self._buf.popleft()
        cutoff = t - self._max_age
        while self._buf and self._buf[0][0] < cutoff:
            self._buf.popleft()

    def reset(self):
        self._buf.clear()

    def fit(self):
        n = len(self._buf)
        if n < 3:
            return None
        t0 = self._buf[0][0]
        sx = sy = sxx = sxy = 0.0
        for t, v in self._buf:
            x = t - t0
            sx += x; sy += v; sxx += x * x; sxy += x * v
        denom = n * sxx - sx * sx
        if abs(denom) < 1e-12:
            return None
        slope = (n * sxy - sx * sy) / denom
        intercept = (sy - slope * sx) / n
        return slope, intercept + slope * (self._buf[-1][0] - t0)

    def __len__(self):
        return len(self._buf)


@dataclass
class WheelEstimator:
    angle_buf: _SlidingFit = field(default_factory=lambda: _SlidingFit(80, 3.0))
    omega_buf: _SlidingFit = field(default_factory=lambda: _SlidingFit(80, 3.5))
    last_omega: Optional[float] = None
    cumulative_angle: float = 0.0
    last_t: Optional[float] = None

    def reset(self):
        self.angle_buf.reset(); self.omega_buf.reset()
        self.last_omega = None; self.cumulative_angle = 0.0; self.last_t = None

    def update(self, t, d_angle):
        if self.last_t is None:
            self.last_t = t; self.angle_buf.push(t, 0.0)
            return MotionEstimate()
        self.cumulative_angle += d_angle
        self.angle_buf.push(t, self.cumulative_angle)
        fit = self.angle_buf.fit()
        if fit is None:
            return MotionEstimate(samples=len(self.angle_buf))
        omega, _ = fit
        self.omega_buf.push(t, omega)
        af = self.omega_buf.fit()
        alpha = af[0] if af else 0.0
        self.last_omega = omega; self.last_t = t
        return MotionEstimate(omega=omega, alpha=alpha, samples=len(self.angle_buf))

    def predict_angle_at(self, t_future):
        if self.last_t is None or self.last_omega is None:
            return None
        dt = max(0, t_future - self.last_t)
        af = self.omega_buf.fit()
        alpha = af[0] if af else 0.0
        return self.cumulative_angle + self.last_omega * dt + 0.5 * alpha * dt * dt


@dataclass
class BallEstimator:
    angle_buf: _SlidingFit = field(default_factory=lambda: _SlidingFit(60, 2.5))
    omega_buf: _SlidingFit = field(default_factory=lambda: _SlidingFit(60, 3.0))
    radius_buf: _SlidingFit = field(default_factory=lambda: _SlidingFit(80, 3.5))
    last_omega: Optional[float] = None
    last_radius: Optional[float] = None
    last_t: Optional[float] = None
    last_angle_unwrapped: float = 0.0
    cumulative_angle: float = 0.0
    initialized: bool = False
    peak_omega: float = 0.0

    def reset(self):
        self.angle_buf.reset(); self.omega_buf.reset(); self.radius_buf.reset()
        self.last_omega = None; self.last_radius = None; self.last_t = None
        self.last_angle_unwrapped = 0.0; self.cumulative_angle = 0.0
        self.initialized = False; self.peak_omega = 0.0

    def update(self, t, angle_rad, radius_px):
        if not self.initialized:
            self.last_angle_unwrapped = angle_rad
            self.cumulative_angle = 0.0; self.last_t = t
            self.angle_buf.push(t, 0.0); self.radius_buf.push(t, radius_px)
            self.initialized = True
            return MotionEstimate(radius=radius_px)

        diff = angle_rad - (self.last_angle_unwrapped % (2 * math.pi))
        while diff > math.pi: diff -= 2 * math.pi
        while diff < -math.pi: diff += 2 * math.pi
        self.last_angle_unwrapped += diff
        self.cumulative_angle += diff
        self.angle_buf.push(t, self.cumulative_angle)
        self.radius_buf.push(t, radius_px)

        fit = self.angle_buf.fit()
        if fit is None:
            return MotionEstimate(radius=radius_px)
        omega, _ = fit
        self.omega_buf.push(t, omega)
        af = self.omega_buf.fit()
        alpha = af[0] if af else 0.0
        rf = self.radius_buf.fit()
        rr = rf[0] if rf else 0.0
        rn = rf[1] if rf else radius_px
        self.last_omega = omega; self.last_radius = rn; self.last_t = t
        if abs(omega) > self.peak_omega:
            self.peak_omega = abs(omega)
        return MotionEstimate(omega=omega, alpha=alpha, radius=rn,
                              radius_rate=rr, samples=len(self.angle_buf))

    def predict_drop_time(self, drop_radius, t_now, max_horizon=20.0):
        if self.last_radius is None or self.last_t is None:
            return None
        rf = self.radius_buf.fit()
        if rf is None:
            return None
        rate, latest_r = rf
        if rate >= -0.3:
            return None
        s = (drop_radius - latest_r) / rate
        if s < 0 or s > max_horizon:
            return None
        return t_now + s

    def predict_angle_at(self, t_future):
        if self.last_t is None or self.last_omega is None:
            return None
        dt = max(0, t_future - self.last_t)
        af = self.omega_buf.fit()
        alpha = af[0] if af else 0.0
        return self.cumulative_angle + self.last_omega * dt + 0.5 * alpha * dt * dt
