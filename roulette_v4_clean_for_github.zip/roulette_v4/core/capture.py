"""Capture sources — V3 optimized for smooth display on macOS Intel.

Key optimizations:
- mss grabs BGRA natively; we keep it as-is and only convert once
- Reduced memory copies by using numpy views
- Smaller grab buffer option for processing
"""
from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from typing import Optional

import cv2
import mss
import mss.tools
import numpy as np

log = logging.getLogger(__name__)


class CaptureSource(ABC):
    @abstractmethod
    def grab(self) -> Optional[np.ndarray]:
        """Return BGR uint8 image, or None on failure."""

    @abstractmethod
    def close(self) -> None: ...

    @property
    @abstractmethod
    def description(self) -> str: ...


class ScreenRegionCapture(CaptureSource):
    """Capture a fixed rectangle using mss. Optimized for macOS."""

    def __init__(self, region: tuple[int, int, int, int], monitor: int = 1) -> None:
        x, y, w, h = region
        if w <= 0 or h <= 0:
            raise ValueError(f"Invalid region: {w}x{h}")
        self._region = region
        self._monitor = monitor
        self._sct: Optional[mss.mss] = None
        self._bbox: Optional[dict] = None
        self._init()

    def _init(self):
        self._sct = mss.mss()
        x, y, w, h = self._region
        if self._monitor == 0:
            self._bbox = {"left": x, "top": y, "width": w, "height": h}
        else:
            mons = self._sct.monitors
            if self._monitor >= len(mons):
                self._monitor = 1
            base = mons[self._monitor]
            self._bbox = {
                "left": base["left"] + x,
                "top": base["top"] + y,
                "width": w,
                "height": h,
            }

    def grab(self) -> Optional[np.ndarray]:
        if self._sct is None or self._bbox is None:
            return None
        try:
            raw = self._sct.grab(self._bbox)
        except (mss.exception.ScreenShotError, OSError) as e:
            log.error("Screen grab failed: %s", e)
            return None
        # mss returns BGRA on macOS — drop alpha channel directly (no cvtColor needed)
        img = np.frombuffer(raw.bgra, dtype=np.uint8).reshape(raw.height, raw.width, 4)
        return img[:, :, :3].copy()  # BGR, contiguous

    def close(self):
        if self._sct:
            try:
                self._sct.close()
            except Exception:
                pass
            self._sct = None

    @property
    def description(self):
        x, y, w, h = self._region
        return f"Screen {w}x{h} at ({x},{y}) monitor {self._monitor}"


class VirtualCamCapture(CaptureSource):
    def __init__(self, device_index=0, target_fps=30):
        self._cap = cv2.VideoCapture(device_index, cv2.CAP_AVFOUNDATION)
        if not self._cap.isOpened():
            raise RuntimeError(f"Cannot open camera {device_index}")
        self._cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        self._cap.set(cv2.CAP_PROP_FPS, target_fps)
        self._index = device_index

    def grab(self):
        ok, frame = self._cap.read()
        return frame if ok else None

    def close(self):
        if self._cap:
            self._cap.release()

    @property
    def description(self):
        return f"Camera #{self._index}"


class VideoFileCapture(CaptureSource):
    def __init__(self, path, loop=True, realtime=True):
        self._cap = cv2.VideoCapture(path)
        if not self._cap.isOpened():
            raise RuntimeError(f"Cannot open: {path}")
        self._loop = loop
        self._path = path
        self._fps = self._cap.get(cv2.CAP_PROP_FPS) or 30.0
        self._period = 1.0 / max(1, self._fps)
        self._next_t = time.monotonic()
        self._realtime = realtime

    def grab(self):
        if self._realtime:
            now = time.monotonic()
            if now < self._next_t:
                time.sleep(max(0, self._next_t - now))
            self._next_t += self._period
            if self._next_t < time.monotonic() - self._period:
                self._next_t = time.monotonic() + self._period
        ok, frame = self._cap.read()
        if not ok:
            if self._loop:
                self._cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                ok, frame = self._cap.read()
                return frame if ok else None
            return None
        return frame

    def close(self):
        if self._cap:
            self._cap.release()

    @property
    def description(self):
        return f"File {self._path} ({self._fps:.0f}fps)"


def list_cameras(max_index=6):
    available = []
    for i in range(max_index):
        cap = cv2.VideoCapture(i, cv2.CAP_AVFOUNDATION)
        if cap.isOpened():
            available.append(i)
            cap.release()
    return available


def list_monitors():
    with mss.mss() as sct:
        return [dict(m) for m in sct.monitors]
