"""Ball tracking V4 — robust for real casino streams.

Major improvements:
- Polar annulus search: converts annulus to polar coords, ball appears as a bright
  horizontal streak — much easier to detect than in Cartesian
- Adaptive brightness threshold based on running annulus statistics
- Multi-frame motion accumulation for motion blur resistance
- Trajectory-constrained search: ball must follow circular path, rejects linear noise
- Automatic recovery: if ball lost for N frames, widens search and reduces selectivity
- Proper distinction from wheel markers: markers are static, ball moves
"""
from __future__ import annotations

import logging
import math
from collections import deque
from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np

from .kalman import Kalman2D

log = logging.getLogger(__name__)


@dataclass
class BallState:
    x: float
    y: float
    vx: float
    vy: float
    angle_rad: float
    radius_from_center: float
    detected: bool
    confidence: float


class BallTracker:
    def __init__(self, annulus_inner=0.65, annulus_outer=1.10, trail_len=50):
        self._kalman = Kalman2D(process_var=10.0, measurement_var=3.0, gate_sigma=5.0)
        self._inner = annulus_inner
        self._outer = annulus_outer
        self._prev_gray: Optional[np.ndarray] = None
        self._prev_gray2: Optional[np.ndarray] = None
        self._prev_gray3: Optional[np.ndarray] = None
        self._frames_since = 0
        self._trail: deque[tuple[float, float]] = deque(maxlen=trail_len)
        self._mask_cache: Optional[tuple] = None
        self._detection_count = 0
        # Running statistics for adaptive threshold
        self._bright_thresh_ema = 180.0

    def reset(self):
        self._kalman.reset()
        self._prev_gray = self._prev_gray2 = self._prev_gray3 = None
        self._frames_since = 0
        self._trail.clear()
        self._mask_cache = None
        self._detection_count = 0
        self._bright_thresh_ema = 180.0

    def _annulus_mask(self, shape, center, radius):
        key = (int(center[0]), int(center[1]), int(radius), shape[0], shape[1])
        if self._mask_cache and self._mask_cache[0] == key:
            return self._mask_cache[1]
        h, w = shape
        m = np.zeros((h, w), dtype=np.uint8)
        cv2.circle(m, (int(center[0]), int(center[1])), int(radius * self._outer), 255, -1)
        cv2.circle(m, (int(center[0]), int(center[1])), int(radius * self._inner), 0, -1)
        self._mask_cache = (key, m)
        return m

    def _detect_ball(self, gray, frame_bgr, center, radius, mask):
        h, w = gray.shape

        # Adaptive brightness threshold
        ann_pix = gray[mask > 0]
        if len(ann_pix) < 30:
            return None
        # Ball is in top 3-5% of brightness within annulus
        q96 = float(np.quantile(ann_pix, 0.96))
        q99 = float(np.quantile(ann_pix, 0.99))
        # EMA smooth the threshold
        target_thresh = max(150, min(q96, q99 - 10))
        self._bright_thresh_ema = 0.9 * self._bright_thresh_ema + 0.1 * target_thresh

        _, bright = cv2.threshold(gray, int(self._bright_thresh_ema), 255, cv2.THRESH_BINARY)
        bright = cv2.bitwise_and(bright, bright, mask=mask)

        # Multi-frame motion accumulation (handles motion blur)
        motion = np.zeros_like(gray)
        frames = [f for f in [self._prev_gray, self._prev_gray2, self._prev_gray3]
                  if f is not None and f.shape == gray.shape]
        for prev in frames:
            d = cv2.absdiff(gray, prev)
            _, m = cv2.threshold(d, 8, 255, cv2.THRESH_BINARY)
            motion = cv2.bitwise_or(motion, m)
        motion = cv2.bitwise_and(motion, motion, mask=mask)

        # White/silver color
        hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
        white = cv2.inRange(hsv, np.array([0, 0, 165]), np.array([180, 70, 255]))
        white = cv2.bitwise_and(white, white, mask=mask)

        # === Combine: primary = bright AND (motion OR white) ===
        combo = cv2.bitwise_and(bright, cv2.bitwise_or(motion, white))

        # Fallbacks
        if cv2.countNonZero(combo) < 2:
            combo = cv2.bitwise_and(bright, motion)
        if cv2.countNonZero(combo) < 2:
            # During recovery (many missed frames), use just bright
            if self._frames_since > 10:
                combo = bright
            else:
                combo = cv2.bitwise_and(white, motion)
        if cv2.countNonZero(combo) < 2:
            return None

        # Morphology
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        combo = cv2.morphologyEx(combo, cv2.MORPH_CLOSE, k)
        combo = cv2.morphologyEx(combo, cv2.MORPH_OPEN, k)

        contours, _ = cv2.findContours(combo, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return None

        max_ball_area = (radius * 0.12) ** 2 * math.pi
        min_ball_area = 3
        expected_rim_d = radius * 0.88  # ball sits at ~88% of wheel radius

        best_pt, best_sc = None, 0.0

        for c in contours:
            area = cv2.contourArea(c)
            if area < min_ball_area or area > max_ball_area:
                continue
            (x, y), cr = cv2.minEnclosingCircle(c)
            if cr < 1 or cr > radius * 0.12:
                continue

            d = math.hypot(x - center[0], y - center[1])

            # 1. Rim proximity: ball should be near the outer track
            rim_score = max(0, 1 - abs(d - expected_rim_d) / (radius * 0.25))

            # 2. Brightness at point
            bx, by = min(max(int(x), 0), w - 1), min(max(int(y), 0), h - 1)
            bright_score = min(1, gray[by, bx] / 220.0)

            # 3. Circularity (ball is round)
            perim = cv2.arcLength(c, True)
            circ = min(1, 4 * math.pi * area / (perim * perim)) if perim > 0 else 0

            # 4. Motion at this point (moving = ball, static = wheel marker)
            motion_score = 0.0
            if motion[by, bx] > 0:
                motion_score = 0.8
            elif self._frames_since > 10:
                motion_score = 0.3  # more lenient during recovery

            # 5. Temporal consistency with Kalman prediction
            temporal = 0.5
            if self._kalman.initialized:
                px, py, _, _ = self._kalman.state
                pred_dist = math.hypot(x - px, y - py)
                # Scale gate with speed — faster ball = wider gate
                gate = max(radius * 0.15, min(radius * 0.4, self._kalman.velocity * 0.3))
                temporal = max(0, 1 - pred_dist / gate)
            elif self._frames_since > 15:
                temporal = 0.6  # no prediction yet, be lenient

            # 6. Size consistency
            expected_r = max(2, radius * 0.025)
            size_score = max(0, 1 - abs(cr - expected_r) / max(1, expected_r * 3))

            score = (
                0.25 * rim_score +
                0.15 * bright_score +
                0.10 * circ +
                0.20 * motion_score +
                0.20 * temporal +
                0.10 * size_score
            )

            if score > best_sc:
                best_sc = score
                best_pt = (float(x), float(y), score)

        # Lower threshold during recovery mode
        min_score = 0.15 if self._frames_since < 10 else 0.10
        return best_pt if best_sc > min_score else None

    def _polar_detect(self, gray, center, radius, mask):
        """Polar-space detection: convert annulus to polar image, find ball as
        bright horizontal feature. More robust for circular motion."""
        try:
            outer_r = radius * self._outer
            polar = cv2.warpPolar(gray, (180, 360), center, outer_r,
                                  cv2.WARP_FILL_OUTLIERS + cv2.INTER_LINEAR + cv2.WARP_POLAR_LINEAR)
        except cv2.error:
            return None

        # In polar space, inner boundary is at row = inner_frac * 180
        inner_row = int(self._inner / self._outer * 180)
        polar_roi = polar[inner_row:, :]

        if polar_roi.size == 0:
            return None

        # Find brightest point in polar ROI
        thresh_val = max(160, float(np.quantile(polar_roi, 0.97)))
        _, bright = cv2.threshold(polar_roi, int(thresh_val), 255, cv2.THRESH_BINARY)

        # Find contour in polar space
        contours, _ = cv2.findContours(bright, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return None

        best = None
        best_area = 0
        for c in contours:
            area = cv2.contourArea(c)
            if area < 3 or area > 500:
                continue
            if area > best_area:
                best_area = area
                M = cv2.moments(c)
                if M["m00"] > 0:
                    # Polar coords: x = angle column, y = radius row
                    px = M["m10"] / M["m00"]  # angle index
                    py = M["m01"] / M["m00"] + inner_row  # radius index
                    best = (px, py)

        if best is None:
            return None

        # Convert polar back to Cartesian
        angle_rad = best[0] / 360.0 * 2 * math.pi
        r_frac = best[1] / 180.0
        actual_r = r_frac * outer_r
        x = center[0] + actual_r * math.cos(angle_rad)
        y = center[1] + actual_r * math.sin(angle_rad)

        return (x, y, 0.35)

    def update(self, frame_bgr, wheel_center, wheel_radius, dt):
        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape
        mask = self._annulus_mask((h, w), wheel_center, wheel_radius)

        px, py, vx, vy = self._kalman.predict(dt)

        # Strategy 1: Multi-cue Cartesian detection
        result = self._detect_ball(gray, frame_bgr, wheel_center, wheel_radius, mask)

        # Strategy 2: Polar-space detection (good for fast motion)
        if result is None and self._frames_since > 3:
            result = self._polar_detect(gray, wheel_center, wheel_radius, mask)

        # Strategy 3: Motion centroid fallback
        if result is None and self._frames_since > 5:
            result = self._motion_centroid(gray, wheel_center, wheel_radius, mask)

        # Update frame history
        self._prev_gray3 = self._prev_gray2
        self._prev_gray2 = self._prev_gray
        self._prev_gray = gray

        detected = result is not None
        if result is not None:
            x, y, score = result
            accepted = self._kalman.update(x, y)
            if accepted:
                self._frames_since = 0
                self._detection_count += 1
                x, y, vx, vy = self._kalman.state
                self._trail.append((x, y))
            else:
                self._frames_since += 1
                self._kalman.miss()
                x, y = px, py
                detected = False
        else:
            self._frames_since += 1
            self._kalman.miss()
            x, y = px, py

        if not self._kalman.initialized:
            return BallState(x=0, y=0, vx=0, vy=0, angle_rad=0,
                             radius_from_center=0, detected=False, confidence=0)

        ang = math.atan2(y - wheel_center[1], x - wheel_center[0])
        rfc = math.hypot(x - wheel_center[0], y - wheel_center[1])
        decay = math.exp(-self._frames_since / 8.0)
        conf = (result[2] if result and detected else 0.15) * decay
        return BallState(
            x=float(x), y=float(y), vx=float(vx), vy=float(vy),
            angle_rad=float(ang), radius_from_center=float(rfc),
            detected=detected, confidence=max(0, min(1, conf)),
        )

    def _motion_centroid(self, gray, center, radius, mask):
        if self._prev_gray is None or self._prev_gray.shape != gray.shape:
            return None
        diff = cv2.absdiff(gray, self._prev_gray)
        _, thresh = cv2.threshold(diff, 12, 255, cv2.THRESH_BINARY)
        thresh = cv2.bitwise_and(thresh, thresh, mask=mask)
        if cv2.countNonZero(thresh) < 4:
            return None
        M = cv2.moments(thresh)
        if M["m00"] < 1:
            return None
        mx, my = M["m10"] / M["m00"], M["m01"] / M["m00"]
        d = math.hypot(mx - center[0], my - center[1])
        if d < radius * self._inner * 0.7 or d > radius * self._outer * 1.3:
            return None
        return (mx, my, 0.20)

    @property
    def trail(self):
        return list(self._trail)

    @property
    def frames_since_detection(self):
        return self._frames_since
