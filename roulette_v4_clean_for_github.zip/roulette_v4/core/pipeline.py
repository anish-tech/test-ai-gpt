"""Pipeline V4 — countdown-aware, improved tracking."""
from __future__ import annotations

import logging
import math
import threading
from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np

from config.defaults import Config
from config.wheel_layouts import get_layout
from .ball_tracker import BallTracker
from .frame_buffer import FpsMeter, FrameBuffer
from .physics import BallEstimator, WheelEstimator
from .predictor import Prediction, SectorPredictor
from .wheel_detector import (WheelDetector, WheelDetection, WheelRotationTracker,
                              MotionEnergyDetector, CountdownDetector)

log = logging.getLogger(__name__)


@dataclass
class PipelineResult:
    timestamp: float
    frame_seq: int
    wheel: Optional[WheelDetection]
    ball_xy: Optional[tuple[float, float]]
    ball_detected: bool
    ball_confidence: float
    ball_trail: list[tuple[float, float]]
    wheel_omega: float
    wheel_alpha: float
    ball_omega: float
    ball_alpha: float
    ball_radius: float
    prediction: Prediction
    process_fps: float
    motion_energy: float
    motion_spinning: bool
    countdown_state: str
    countdown_secs: float
    betting_open: bool


ResultCallback = Callable[[PipelineResult], None]


class Pipeline:
    def __init__(self, cfg: Config, buffer: FrameBuffer, on_result: ResultCallback):
        self._cfg = cfg
        self._buffer = buffer
        self._cb = on_result
        self._stop_ev = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._fps = FpsMeter()
        self._last_t: Optional[float] = None

        layout = get_layout(cfg.layout)
        self._wheel_det = WheelDetector(redetect_every=cfg.wheel_redetect_every)
        self._wheel_rot = WheelRotationTracker()
        self._motion = MotionEnergyDetector(
            threshold=cfg.motion_energy_threshold,
            smooth=cfg.motion_energy_smooth,
        )
        self._countdown = CountdownDetector()
        self._ball = BallTracker(
            annulus_inner=cfg.ball_annulus_inner,
            annulus_outer=cfg.ball_annulus_outer,
        )
        self._wheel_phys = WheelEstimator()
        self._ball_phys = BallEstimator()
        self._predictor = SectorPredictor(
            layout=layout,
            zero_angle_rad=math.radians(cfg.zero_angle_deg),
            scatter_stddev=cfg.scatter_stddev,
        )

    def start(self):
        if self._thread and self._thread.is_alive(): return
        self._stop_ev.clear()
        self._thread = threading.Thread(target=self._run, name="Pipeline", daemon=True)
        self._thread.start()

    def stop(self, timeout=2.0):
        self._stop_ev.set()
        if self._thread: self._thread.join(timeout=timeout)

    def reset_spin(self):
        self._ball.reset(); self._wheel_rot.reset()
        self._wheel_phys.reset(); self._ball_phys.reset()
        self._predictor.reset_spin(); self._motion.reset()
        self._countdown.reset(); self._last_t = None

    def update_zero_angle(self, deg):
        self._predictor.set_zero_angle(math.radians(deg))

    def record_result(self, number):
        self._predictor.record_result(number)

    def fps(self): return self._fps.fps()

    @property
    def predictor(self): return self._predictor

    def _run(self):
        while not self._stop_ev.is_set():
            frame = self._buffer.latest()
            if frame is None: frame = self._buffer.pop(timeout=0.1)
            if frame is None: continue
            try:
                result = self._process(frame.image, frame.timestamp, frame.seq)
                self._cb(result)
            except Exception:
                log.exception("Pipeline error frame %d", frame.seq)
            self._fps.tick()

    def _process(self, image, ts, seq):
        if self._last_t is None:
            dt = 1.0 / max(1, self._cfg.target_fps)
        else:
            dt = max(1e-3, ts - self._last_t)
        self._last_t = ts

        wheel = self._wheel_det.detect(image)
        w_omega = w_alpha = b_omega = b_alpha = b_radius = 0.0
        ball_xy = None; ball_detected = False; ball_conf = 0.0; ball_trail = []
        motion_spinning = False; motion_energy = 0.0

        # Countdown detection (runs on full frame)
        betting_open, cd_secs, cd_state = self._countdown.update(
            image, wheel_center=(wheel.cx, wheel.cy) if wheel else None,
            wheel_radius=wheel.radius if wheel else None)

        if wheel is not None:
            center = (wheel.cx, wheel.cy)
            motion_spinning, motion_energy = self._motion.update(image, center, wheel.radius)

            da = self._wheel_rot.update(image, center, wheel.radius)
            if da is not None:
                ws = self._wheel_phys.update(ts, da)
                w_omega, w_alpha = ws.omega, ws.alpha
            elif self._wheel_phys.last_t:
                ws = self._wheel_phys.update(ts, 0.0)
                w_omega, w_alpha = ws.omega, ws.alpha

            bs = self._ball.update(image, center, wheel.radius, dt)
            ball_detected = bs.detected; ball_conf = bs.confidence
            ball_trail = self._ball.trail

            if self._ball._kalman.initialized:
                ball_xy = (bs.x, bs.y)
                if bs.radius_from_center > 0:
                    bstate = self._ball_phys.update(ts, bs.angle_rad, bs.radius_from_center)
                    b_omega, b_alpha, b_radius = bstate.omega, bstate.alpha, bstate.radius

        pred = self._predictor.predict(
            ts, self._wheel_phys, self._ball_phys,
            motion_spinning=motion_spinning, motion_energy=motion_energy,
            betting_open=betting_open, countdown_secs=cd_secs,
            countdown_state=cd_state,
        )

        return PipelineResult(
            timestamp=ts, frame_seq=seq,
            wheel=wheel, ball_xy=ball_xy,
            ball_detected=ball_detected, ball_confidence=ball_conf,
            ball_trail=ball_trail,
            wheel_omega=w_omega, wheel_alpha=w_alpha,
            ball_omega=b_omega, ball_alpha=b_alpha, ball_radius=b_radius,
            prediction=pred, process_fps=self._fps.fps(),
            motion_energy=motion_energy, motion_spinning=motion_spinning,
            countdown_state=cd_state, countdown_secs=cd_secs,
            betting_open=betting_open,
        )
