"""Frame buffer V3 — dual-path for smooth display.

Two independent paths:
1. Display path: always has the latest frame, never blocks, just atomic swap
2. Processing path: bounded queue for the pipeline to consume

This decouples display FPS from processing FPS.
Display runs at capture rate (~30fps), processing runs at whatever it can (~10-15fps).
"""
from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass
class Frame:
    image: np.ndarray   # BGR uint8
    timestamp: float
    seq: int


class FrameBuffer:
    """Dual-path frame buffer: display + processing."""

    def __init__(self, maxsize: int = 3) -> None:
        self._maxsize = max(1, maxsize)
        # Processing queue
        self._dq: deque[Frame] = deque(maxlen=self._maxsize)
        self._cv = threading.Condition()
        self._closed = False
        self._dropped = 0
        # Display path — atomic latest frame
        self._display_frame: Optional[Frame] = None
        self._display_lock = threading.Lock()

    def push(self, frame: Frame) -> None:
        """Called by capture thread. Updates both display and processing paths."""
        # Update display frame (always latest, no queue)
        with self._display_lock:
            self._display_frame = frame

        # Push to processing queue
        with self._cv:
            if self._closed:
                return
            if len(self._dq) == self._maxsize:
                self._dropped += 1
            self._dq.append(frame)
            self._cv.notify()

    def pop(self, timeout: float = 0.5) -> Optional[Frame]:
        """Blocking pop for processing thread."""
        with self._cv:
            if not self._dq and not self._closed:
                self._cv.wait(timeout=timeout)
            if self._dq:
                return self._dq.popleft()
            return None

    def latest(self) -> Optional[Frame]:
        """Get freshest frame for processing, discard older ones."""
        with self._cv:
            if not self._dq:
                return None
            f = self._dq[-1]
            self._dq.clear()
            return f

    def latest_display(self) -> Optional[Frame]:
        """Get latest frame for display — non-blocking, no queue drain."""
        with self._display_lock:
            return self._display_frame

    def close(self):
        with self._cv:
            self._closed = True
            self._cv.notify_all()

    @property
    def dropped(self):
        with self._cv:
            return self._dropped

    def __len__(self):
        with self._cv:
            return len(self._dq)


class FpsMeter:
    def __init__(self, window=1.0):
        self._window = window
        self._stamps: deque[float] = deque()

    def tick(self):
        now = time.monotonic()
        self._stamps.append(now)
        cutoff = now - self._window
        while self._stamps and self._stamps[0] < cutoff:
            self._stamps.popleft()

    def fps(self):
        if len(self._stamps) < 2:
            return 0.0
        span = self._stamps[-1] - self._stamps[0]
        return (len(self._stamps) - 1) / span if span > 0 else 0.0
