"""Sector prediction V4 — countdown-aware, locks prediction before betting closes.

New features:
- Countdown detection integration: knows when betting window is closing
- Prediction lock: freezes final prediction 4+ seconds before countdown ends
- Better phase detection using motion energy as primary signal
- Dynamic prediction updates during spin
"""
from __future__ import annotations

import math
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .physics import BallEstimator, WheelEstimator
from config.wheel_layouts import WheelLayout


@dataclass
class Prediction:
    landing_number: int
    landing_index: int
    probabilities: np.ndarray
    neighbors: list[int]
    confidence: float
    spin_phase: str
    strategy: str
    seconds_to_drop: float
    drop_angle_world: float
    drop_angle_relative: float
    top5: list[tuple[int, float]]
    countdown_state: str       # "betting_open" | "betting_closed" | "unknown"
    prediction_locked: bool    # True = this is the final locked prediction
    lock_time_remaining: float # seconds until prediction should lock


class SectorBiasAnalyzer:
    def __init__(self, layout, window=200):
        self._layout = layout
        self._history: deque[int] = deque(maxlen=window)
        self._n = layout.n_pockets

    def record(self, number):
        self._history.append(number)

    def reset(self):
        self._history.clear()

    @property
    def count(self):
        return len(self._history)

    def sector_probabilities(self):
        counts = np.ones(self._n, dtype=np.float64)
        for num in self._history:
            try:
                counts[self._layout.number_to_index(num)] += 1
            except ValueError:
                pass
        return counts / counts.sum()

    def hot_sectors(self, k=7):
        probs = self.sector_probabilities()
        devs = sorted(range(self._n), key=lambda i: probs[i], reverse=True)[:k]
        return [(self._layout.index_to_number(i), float(probs[i])) for i in devs]

    def sector_group_bias(self):
        probs = self.sector_probabilities()
        sigma = 2.0
        smoothed = np.zeros_like(probs)
        for i in range(self._n):
            for j in range(self._n):
                d = min(abs(i - j), self._n - abs(i - j))
                smoothed[i] += probs[j] * math.exp(-0.5 * (d / sigma) ** 2)
        s = smoothed.sum()
        return smoothed / s if s > 0 else probs


class DealerSignatureAnalyzer:
    def __init__(self, layout, window=50):
        self._layout = layout
        self._n = layout.n_pockets
        self._history: deque[int] = deque(maxlen=window + 1)
        self._gaps: deque[int] = deque(maxlen=window)

    def record(self, number):
        if self._history:
            try:
                pi = self._layout.number_to_index(self._history[-1])
                ci = self._layout.number_to_index(number)
                self._gaps.append((ci - pi) % self._n)
            except ValueError:
                pass
        self._history.append(number)

    def reset(self):
        self._history.clear(); self._gaps.clear()

    @property
    def count(self):
        return len(self._gaps)

    def predict_from_last(self):
        if len(self._gaps) < 5 or not self._history:
            return None
        try:
            li = self._layout.number_to_index(self._history[-1])
        except ValueError:
            return None
        gc = np.ones(self._n, dtype=np.float64) * 0.5
        for g in self._gaps:
            gc[g] += 1
        gp = gc / gc.sum()
        sigma = 2.0
        sm = np.zeros(self._n, dtype=np.float64)
        for i in range(self._n):
            for j in range(self._n):
                d = min(abs(i - j), self._n - abs(i - j))
                sm[i] += gp[j] * math.exp(-0.5 * (d / sigma) ** 2)
        sm /= sm.sum()
        result = np.zeros(self._n, dtype=np.float64)
        for gi in range(self._n):
            result[(li + gi) % self._n] = sm[gi]
        return result / result.sum()

    def avg_gap(self):
        return float(np.mean(list(self._gaps))) if len(self._gaps) >= 3 else None


class SectorPredictor:
    def __init__(self, layout, zero_angle_rad=0.0, scatter_stddev=3.0, neighbor_count=5):
        self._layout = layout
        self._zero = zero_angle_rad
        self._scatter = max(1.0, scatter_stddev)
        self._nk = neighbor_count
        self._n = layout.n_pockets
        self._sector_bias = SectorBiasAnalyzer(layout)
        self._dealer_sig = DealerSignatureAnalyzer(layout)
        self._max_radius = 0.0
        self._drop_radius: Optional[float] = None
        self._in_spin = False

        # Prediction lock state
        self._locked_prediction: Optional[Prediction] = None
        self._lock_time: Optional[float] = None
        self._spin_start_time: Optional[float] = None

    @property
    def layout(self):
        return self._layout

    def set_zero_angle(self, rad):
        self._zero = rad

    def reset_spin(self):
        self._max_radius = 0; self._drop_radius = None; self._in_spin = False
        self._locked_prediction = None; self._lock_time = None; self._spin_start_time = None

    def record_result(self, number):
        self._sector_bias.record(number)
        self._dealer_sig.record(number)

    def observe_radius(self, r):
        if r > self._max_radius: self._max_radius = r
        self._drop_radius = self._max_radius * 0.85

    def predict(self, t_now, wheel, ball, motion_spinning=False,
                motion_energy=0.0, betting_open=True, countdown_secs=0.0,
                countdown_state="unknown"):
        has_visual = (wheel.last_omega is not None and
                      ball.last_omega is not None and ball.last_radius is not None)
        omega_b = ball.last_omega or 0.0
        omega_w = wheel.last_omega or 0.0
        ball_radius = ball.last_radius or 0.0
        if ball_radius > 0:
            self.observe_radius(ball_radius)

        # Phase detection — use motion energy as primary signal
        if motion_spinning:
            if not self._in_spin:
                self._in_spin = True
                self._spin_start_time = t_now
                self._locked_prediction = None
                self._lock_time = None
            if has_visual and abs(omega_b) < 1.0:
                phase = "decaying"
            else:
                phase = "spinning"
        elif has_visual and (abs(omega_b) > 1.5 or abs(omega_w) > 0.5):
            if not self._in_spin:
                self._in_spin = True
                self._spin_start_time = t_now
            phase = "spinning" if abs(omega_b) > 1.5 else "decaying"
        else:
            if self._in_spin:
                self._in_spin = False
            phase = "no_spin"

        # === Check if we should lock the prediction ===
        should_lock = False
        lock_time_remaining = 0.0

        if countdown_secs > 0 and countdown_secs < 6.0 and phase != "no_spin":
            lock_time_remaining = max(0, countdown_secs - 2.0)
            if countdown_secs < 4.0:
                should_lock = True

        # If spin has been going for > 8 seconds and we have data, lock
        if (self._spin_start_time and t_now - self._spin_start_time > 8.0 and
                has_visual and phase in ("decaying", "spinning")):
            should_lock = True
            lock_time_remaining = 0.0

        # Return locked prediction if we already locked
        if self._locked_prediction is not None and phase != "no_spin":
            self._locked_prediction.countdown_state = countdown_state
            return self._locked_prediction

        # === Build prediction ===
        visual_probs, visual_conf, secs, dw, dr = None, 0.0, 0.0, 0.0, 0.0
        if has_visual and phase != "no_spin":
            visual_probs, visual_conf, secs, dw, dr = self._visual_predict(t_now, wheel, ball, phase)

        sector_probs = self._sector_bias.sector_group_bias()
        sector_conf = min(0.6, self._sector_bias.count / 100.0)
        dealer_probs = self._dealer_sig.predict_from_last()
        dealer_conf = min(0.5, self._dealer_sig.count / 30.0) if dealer_probs is not None else 0.0
        if dealer_probs is None:
            dealer_probs = np.full(self._n, 1.0 / self._n)

        # Combine
        if visual_probs is not None and visual_conf > 0.05:
            wv = 0.45 * visual_conf
            ws = 0.30 * sector_conf
            wd = 0.25 * dealer_conf
            tw = max(1e-6, wv + ws + wd)
            combined = (wv * visual_probs + ws * sector_probs + wd * dealer_probs) / tw
            strategy = "combined"
            confidence = min(0.95, visual_conf * 0.6 + sector_conf * 0.2 + dealer_conf * 0.2)
        elif sector_conf > 0.05 or dealer_conf > 0.05:
            ws = max(0.01, sector_conf)
            wd = max(0.01, dealer_conf)
            combined = (ws * sector_probs + wd * dealer_probs) / (ws + wd)
            strategy = "sector_bias" if sector_conf > dealer_conf else "dealer_sig"
            confidence = max(sector_conf, dealer_conf) * 0.7
        else:
            combined = np.full(self._n, 1.0 / self._n)
            strategy = "none"
            confidence = 0.01

        s = combined.sum()
        if s > 0: combined /= s
        idx = int(np.argmax(combined))
        landing = self._layout.index_to_number(idx)
        neighbors = self._layout.neighbors(landing, self._nk)
        top5_idx = np.argsort(combined)[::-1][:5]
        top5 = [(self._layout.index_to_number(int(i)), float(combined[i])) for i in top5_idx]

        pred = Prediction(
            landing_number=landing, landing_index=idx,
            probabilities=combined, neighbors=neighbors,
            confidence=confidence, spin_phase=phase,
            strategy=strategy, seconds_to_drop=secs,
            drop_angle_world=dw, drop_angle_relative=dr,
            top5=top5, countdown_state=countdown_state,
            prediction_locked=should_lock,
            lock_time_remaining=lock_time_remaining,
        )

        if should_lock and confidence > 0.05:
            self._locked_prediction = pred
            self._lock_time = t_now

        return pred

    def _visual_predict(self, t_now, wheel, ball, phase):
        n = self._n
        t_drop = ball.predict_drop_time(self._drop_radius, t_now) if self._drop_radius else None
        if t_drop:
            secs = max(0, t_drop - t_now)
            ba = ball.predict_angle_at(t_drop)
            wa = wheel.predict_angle_at(t_drop)
        else:
            ob = abs(ball.last_omega or 0)
            la = 2.0 if ob > 6 else (1.0 if ob > 3 else 0.3)
            secs = la
            ba = ball.predict_angle_at(t_now + la)
            wa = wheel.predict_angle_at(t_now + la)
        if ba is None or wa is None:
            return None, 0.0, 0.0, 0.0, 0.0
        rel = ba - wa - self._zero
        rel_norm = (-rel) % (2 * math.pi)
        arc = 2 * math.pi / n
        idx = int(round(rel_norm / arc)) % n
        conf = self._conf(wheel, ball, secs, phase)
        sigma = self._scatter * (1.8 - conf)
        sigma = max(1.2, min(sigma, n / 3))
        probs = self._gauss(idx, sigma, n)
        return probs, conf, secs, ba % (2 * math.pi), rel_norm

    def _conf(self, wheel, ball, secs, phase):
        cw = min(1, len(wheel.angle_buf) / 20)
        cb = min(1, len(ball.angle_buf) / 15)
        dq = (cw * cb) ** 0.5
        tq = max(0, 1 - secs / 5)
        pb = {"spinning": 0, "decaying": 0.25, "dropped": 0.35}.get(phase, 0)
        return max(0.03, min(0.90, 0.35 * dq + 0.40 * tq + 0.25 * (1 + pb)))

    @staticmethod
    def _gauss(center, sigma, n):
        d = np.minimum(np.abs(np.arange(n) - center), n - np.abs(np.arange(n) - center))
        p = np.exp(-0.5 * (d / sigma) ** 2)
        s = p.sum()
        return p / s if s > 0 else np.full(n, 1.0 / n)

    @property
    def sector_bias(self):
        return self._sector_bias
    @property
    def dealer_sig(self):
        return self._dealer_sig
