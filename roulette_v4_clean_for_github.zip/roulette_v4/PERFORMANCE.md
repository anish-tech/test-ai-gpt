# Performance Tuning (Intel Mac)

The pipeline is designed to hold 30 FPS on a 2019 i7 MacBook Pro with the
Intel Iris Plus / Radeon Pro 555X. Here is how to keep it there.

## The big knobs (in order of impact)

1. **Capture region size.** Capture only the wheel, not the whole browser.
   1920x1080 of full screen is ~3x the work of an 800x800 wheel crop.
2. **Target FPS.** 30 is the sweet spot. 60 doubles CPU for a roulette wheel
   that physically updates ~30 times per visible degree anyway.
3. **Detection cadence.** The wheel center is re-detected every N frames, not
   every frame. Default N=15. Lower it only if your wheel drifts in the frame.
4. **Ball ROI.** Once the wheel is found, ball search is restricted to an
   annulus around it. This is a 5-10x speedup over full-frame search.

## Settings cheatsheet

| Mac                          | FPS | Region          | Wheel re-detect |
|------------------------------|-----|-----------------|-----------------|
| 2019 MBP 13" i5              | 24  | 720x720         | every 30 frames |
| 2019 MBP 15"/16" i7          | 30  | 900x900         | every 15 frames |
| 2019 MBP 16" i9 + Radeon Pro | 30  | 1080x1080       | every 10 frames |

## Things that help

- Plug in. Battery throttling kills FPS.
- Close Chrome tabs you don't need.
- Quit Slack, Spotify, Docker.
- Set the browser running the casino to a fixed window size.

## Things that hurt (don't do them)

- Running with the app's own window overlapping the capture region. macOS
  will composite both, frames get noisy, and recursive capture artifacts can
  appear. Move the app to a second monitor or to the side.
- "Maximizing" the casino window every spin. Re-calibrate when geometry
  changes.

## Diagnosing

The status bar shows three numbers: capture FPS, process FPS, and CPU%.
If capture FPS is fine but process FPS is half, your pipeline is CPU-bound:
shrink the region or raise the wheel re-detect interval.
