# Calibration Wizard

Before going live, run the wizard once per casino/wheel layout. It takes ~60
seconds and saves you hours of bad predictions.

## Steps

1. Open the casino in your browser. Get to a wheel that is **idle** (no spin
   in progress).
2. In this app, click "Calibrate".
3. The wizard grabs a frame. Click "Detect wheel" — you should see a green
   circle land cleanly on the rim. If not:
   - Adjust brightness on the casino site.
   - Try again with a tighter crop.
4. Choose the wheel **layout**:
   - European single-zero (37 pockets, default).
   - American double-zero (38 pockets).
5. Mark the green zero pocket so the layout aligns with what you see.
   Click on the visible "0" or "00".
6. Click Finish. The calibration is saved under `~/.roulette_tracker/calibrations/`.

## When to recalibrate

- Browser window resized.
- Casino site UI updated.
- Switched casinos.
- Switched between European and American wheels.

## Tips

- Calibrate during the dealer's idle phase, not mid-spin.
- If the wheel has a glossy reflection over the rim, try a different camera
  angle or OBS color correction.
