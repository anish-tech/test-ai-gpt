# Roulette Visual Tracker (macOS Intel)

Real-time roulette wheel and ball tracking with physics-based sector prediction,
optimized for Intel MacBook Pro on macOS Sonoma.

## What this is

A computer-vision pipeline that watches a roulette stream (browser window, screen
region, or virtual camera), tracks the wheel and ball, estimates their rotational
state, and predicts the most likely landing sector along with its neighbors.

## What this is not

A guaranteed winning system. Visual ballistics on streamed video has fundamental
limits: video compression, variable frame timing, and lack of physical wheel
calibration cap real-world accuracy. The tool is built to give you a calibrated
*probability distribution* over sectors with honest confidence numbers — not a
single guaranteed pocket.

## Requirements

- MacBook Pro 2019 (Intel) or similar Intel Mac
- macOS Sonoma (14.x). Should also run on Ventura.
- Python 3.11 (3.10 and 3.12 work; 3.11 is the tested target)
- Screen Recording permission granted to your terminal/IDE

See `INSTALL.md`, `PERMISSIONS.md`, `PERFORMANCE.md`, `CALIBRATION.md`.

## Quick start

    python -m venv .venv
    source .venv/bin/activate
    pip install -r requirements.txt
    python run.py

## Modes

- **Live**: capture a screen region or window and track in real time.
- **Test**: feed a recorded video file through the same pipeline (no capture
  permissions needed). Useful for tuning.
- **Calibrate**: walk through the wheel-detection wizard before going live.

## Headless smoke test (no permissions needed)

    python -m tests.sample_runner

This generates a synthetic spinning wheel in memory and runs the full pipeline
against it — verifies the install without Screen Recording permission.

## License

Personal use. No warranty. Gambling involves risk; use this tool to study the
game, not as financial advice.
