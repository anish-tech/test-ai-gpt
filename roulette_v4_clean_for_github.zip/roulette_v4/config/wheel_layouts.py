"""European and American roulette wheel layouts.

The order is the physical pocket order on the wheel, going clockwise starting
from the green zero. Used to map predicted landing angle to a pocket number,
and to compute neighboring numbers (physical neighbors on the wheel).
"""
from __future__ import annotations

from dataclasses import dataclass

EUROPEAN_ORDER: tuple[int, ...] = (
    0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10,
    5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26,
)

AMERICAN_ORDER: tuple[int, ...] = (
    0, 28, 9, 26, 30, 11, 7, 20, 32, 17, 5, 22, 34, 15, 3, 24, 36, 13, 1,
    -1,  # -1 represents 00
    27, 10, 25, 29, 12, 8, 19, 31, 18, 6, 21, 33, 16, 4, 23, 35, 14, 2,
)

RED_NUMBERS: frozenset[int] = frozenset(
    {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}
)


@dataclass(frozen=True)
class WheelLayout:
    name: str
    order: tuple[int, ...]

    @property
    def n_pockets(self) -> int:
        return len(self.order)

    @property
    def pocket_arc_deg(self) -> float:
        return 360.0 / self.n_pockets

    def number_to_index(self, number: int) -> int:
        """Index in physical pocket order. -1 means 00."""
        return self.order.index(number)

    def index_to_number(self, idx: int) -> int:
        return self.order[idx % self.n_pockets]

    def display(self, number: int) -> str:
        if number == -1:
            return "00"
        return str(number)

    def is_red(self, number: int) -> bool:
        return number in RED_NUMBERS

    def is_green(self, number: int) -> bool:
        return number in (0, -1)

    def neighbors(self, number: int, k: int) -> list[int]:
        """k physical neighbors on each side, plus the number itself.
        Returns 2k+1 numbers in physical order."""
        idx = self.number_to_index(number)
        n = self.n_pockets
        return [self.order[(idx + offset) % n] for offset in range(-k, k + 1)]


EUROPEAN = WheelLayout("european", EUROPEAN_ORDER)
AMERICAN = WheelLayout("american", AMERICAN_ORDER)


def get_layout(name: str) -> WheelLayout:
    if name == "american":
        return AMERICAN
    return EUROPEAN
