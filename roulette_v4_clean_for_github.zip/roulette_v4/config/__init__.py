"""Configuration package."""
from .defaults import Config, load_config, save_config

__all__ = ["Config", "load_config", "save_config"]
