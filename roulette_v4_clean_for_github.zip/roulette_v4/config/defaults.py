"""Configuration — V3 with multi-strategy prediction."""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

CONFIG_DIR = Path.home() / ".roulette_tracker"
CONFIG_FILE = CONFIG_DIR / "config.json"
CALIB_DIR = CONFIG_DIR / "calibrations"
DB_FILE = CONFIG_DIR / "history.sqlite3"


@dataclass
class Config:
    # Capture
    target_fps: int = 30
    capture_source: str = "screen_region"
    region: tuple[int, int, int, int] = (100, 100, 900, 900)
    monitor_index: int = 1

    # Processing
    wheel_redetect_every: int = 90
    enable_clahe: bool = True

    # Visual detection
    ball_annulus_inner: float = 0.65
    ball_annulus_outer: float = 1.10
    motion_energy_threshold: float = 8.0   # above = spinning
    motion_energy_smooth: float = 0.85     # EMA factor

    # Wheel layout
    layout: str = "european"
    zero_angle_deg: float = 0.0

    # Prediction strategy
    history_size: int = 200                # more history = better stats
    min_confidence_to_show: float = 0.02
    scatter_stddev: float = 3.0
    sector_bias_weight: float = 0.35       # weight for statistical bias
    motion_pred_weight: float = 0.35       # weight for visual motion prediction
    neighbor_pred_weight: float = 0.30     # weight for neighbor/dealer signature

    # UI
    show_overlay: bool = True
    show_heatmap: bool = True
    show_ball_trail: bool = True
    show_debug: bool = True

    calibration_name: str = "default"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Config":
        valid = set(cls.__dataclass_fields__)
        clean = {k: v for k, v in d.items() if k in valid}
        if "region" in clean and isinstance(clean["region"], list):
            clean["region"] = tuple(clean["region"])
        return cls(**clean)


def _ensure_dirs() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CALIB_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> Config:
    _ensure_dirs()
    if not CONFIG_FILE.exists():
        cfg = Config()
        save_config(cfg)
        return cfg
    try:
        with CONFIG_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return Config.from_dict(data)
    except (OSError, json.JSONDecodeError) as e:
        log.warning("Config load failed (%s); defaults.", e)
        return Config()


def save_config(cfg: Config) -> None:
    _ensure_dirs()
    tmp = CONFIG_FILE.with_suffix(".json.tmp")
    try:
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(cfg.to_dict(), f, indent=2)
        tmp.replace(CONFIG_FILE)
    except OSError as e:
        log.error("Config save failed: %s", e)
