# macOS Permissions

This app needs **Screen Recording** to capture. It does *not* need Camera
unless you use OBS Virtual Camera (then Camera is required too).

## Granting Screen Recording

1. System Settings -> Privacy & Security -> Screen Recording.
2. Click the + button.
3. Add the *terminal* you launch from (Terminal.app, iTerm, VS Code, PyCharm —
   whichever runs `python run.py`).
4. **Fully quit** that terminal (Cmd-Q) and reopen. macOS does not pick up the
   permission until the process restarts.
5. Launch the app again.

## Verifying

The app shows capture FPS in the status bar:

- Positive FPS: capture working.
- 0.0 FPS: no permission or capture failing. Frames will be black.

## Camera (only for OBS Virtual Camera)

System Settings -> Privacy & Security -> Camera -> enable for your terminal.

## Why your IDE might be the issue

If you launch from VS Code, VS Code itself needs Screen Recording — not just
the embedded terminal. Same for PyCharm. This is a macOS sandbox quirk.
