"""Sample runner — feed a video file through the pipeline for testing."""
from __future__ import annotations

import argparse
import sys
import time

import cv2

# Add parent to path
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent))

from config.defaults import Config
from core.frame_buffer import FrameBuffer, Frame
from core.pipeline import Pipeline, PipelineResult


def main():
    ap = argparse.ArgumentParser(description="Run pipeline on a video file")
    ap.add_argument("video", help="Path to .mp4 / .avi file")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--layout", default="european")
    ap.add_argument("--show", action="store_true", help="Show opencv window")
    args = ap.parse_args()

    cfg = Config(target_fps=args.fps, layout=args.layout)
    buf = FrameBuffer(maxsize=3)

    results: list[PipelineResult] = []

    def on_result(r: PipelineResult):
        results.append(r)
        pred = r.prediction
        if pred and pred.spin_phase != "no_spin":
            print(
                f"[{r.frame_seq:5d}] phase={pred.spin_phase:8s} "
                f"predict={pred.landing_number:2d} conf={pred.confidence:.0%} "
                f"drop={pred.seconds_to_drop:.1f}s "
                f"w_omega={r.wheel_omega:.2f} b_omega={r.ball_omega:.2f}"
            )
        if args.show and r.wheel is not None:
            img = r.image.copy()
            cx, cy, rad = int(r.wheel.cx), int(r.wheel.cy), int(r.wheel.radius)
            cv2.circle(img, (cx, cy), rad, (0, 220, 180), 2)
            if r.ball_xy:
                bx, by = int(r.ball_xy[0]), int(r.ball_xy[1])
                cv2.circle(img, (bx, by), 6, (0, 255, 255), 2)
            cv2.imshow("Pipeline", img)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                pass

    pipeline = Pipeline(cfg, buf, on_result)
    pipeline.start()

    cap = cv2.VideoCapture(args.video)
    if not cap.isOpened():
        print(f"Cannot open {args.video}")
        return

    seq = 0
    period = 1.0 / cfg.target_fps
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        seq += 1
        buf.push(Frame(image=frame, timestamp=time.monotonic(), seq=seq))
        time.sleep(period * 0.5)  # pace it

    time.sleep(1.0)
    pipeline.stop()
    cap.release()
    if args.show:
        cv2.destroyAllWindows()

    print(f"\nProcessed {seq} frames, got {len(results)} results")
    spins = [r for r in results if r.prediction and r.prediction.spin_phase != "no_spin"]
    print(f"Spin detections: {len(spins)}")


if __name__ == "__main__":
    main()
