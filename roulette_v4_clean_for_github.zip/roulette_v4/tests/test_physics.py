"""Unit tests for physics estimators."""
import math
import unittest

from core.physics import WheelEstimator, BallEstimator


class TestWheelEstimator(unittest.TestCase):
    def test_constant_speed(self):
        w = WheelEstimator()
        omega_true = 3.0
        dt = 1.0 / 30.0
        d_angle = omega_true * dt
        t = 0.0
        for _ in range(90):
            t += dt
            state = w.update(t, d_angle)
        self.assertAlmostEqual(state.omega, omega_true, delta=0.5)

    def test_predict_angle(self):
        w = WheelEstimator()
        dt = 1.0 / 30.0
        t = 0.0
        for _ in range(60):
            t += dt
            w.update(t, 0.1)
        future = w.predict_angle_at(t + 1.0)
        self.assertIsNotNone(future)
        self.assertGreater(future, w.cumulative_angle)


class TestBallEstimator(unittest.TestCase):
    def test_decaying_speed(self):
        b = BallEstimator()
        dt = 1.0 / 30.0
        t = 0.0
        omega0 = 20.0
        decay = 0.995
        radius0 = 200.0
        for i in range(120):
            t += dt
            omega = omega0 * (decay ** i)
            angle = (omega * t) % (2 * math.pi)
            radius = radius0 - i * 0.3
            state = b.update(t, angle, radius)
        self.assertGreater(state.samples, 50)
        self.assertLess(abs(state.omega), omega0)

    def test_drop_time(self):
        b = BallEstimator()
        dt = 1.0 / 30.0
        t = 0.0
        for i in range(90):
            t += dt
            angle = (10.0 * t) % (2 * math.pi)
            radius = 200.0 - i * 0.8
            b.update(t, angle, radius)
        drop_t = b.predict_drop_time(150.0, t)
        if drop_t is not None:
            self.assertGreater(drop_t, t)


if __name__ == "__main__":
    unittest.main()
