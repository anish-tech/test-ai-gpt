"""Unit tests for wheel layouts."""
import unittest

from config.wheel_layouts import EUROPEAN, AMERICAN, get_layout


class TestEuropean(unittest.TestCase):
    def test_pocket_count(self):
        self.assertEqual(EUROPEAN.n_pockets, 37)

    def test_zero_at_start(self):
        self.assertEqual(EUROPEAN.order[0], 0)

    def test_neighbors(self):
        n = EUROPEAN.neighbors(0, 2)
        self.assertEqual(len(n), 5)
        self.assertEqual(n[2], 0)

    def test_display(self):
        self.assertEqual(EUROPEAN.display(0), "0")
        self.assertEqual(EUROPEAN.display(32), "32")

    def test_colors(self):
        self.assertTrue(EUROPEAN.is_green(0))
        self.assertTrue(EUROPEAN.is_red(1))
        self.assertFalse(EUROPEAN.is_red(2))
        self.assertFalse(EUROPEAN.is_green(1))

    def test_arc(self):
        self.assertAlmostEqual(EUROPEAN.pocket_arc_deg, 360.0 / 37, places=4)


class TestAmerican(unittest.TestCase):
    def test_pocket_count(self):
        self.assertEqual(AMERICAN.n_pockets, 38)

    def test_double_zero(self):
        self.assertIn(-1, AMERICAN.order)
        self.assertEqual(AMERICAN.display(-1), "00")

    def test_green_double_zero(self):
        self.assertTrue(AMERICAN.is_green(-1))


class TestGetLayout(unittest.TestCase):
    def test_european(self):
        self.assertEqual(get_layout("european").name, "european")

    def test_american(self):
        self.assertEqual(get_layout("american").name, "american")

    def test_default(self):
        self.assertEqual(get_layout("unknown").name, "european")


if __name__ == "__main__":
    unittest.main()
