"""Unit tests for Kalman filters."""
import math
import unittest

from core.kalman import Kalman2D, AngleKalman, angle_unwrap


class TestAngleUnwrap(unittest.TestCase):
    def test_no_wrap(self):
        self.assertAlmostEqual(angle_unwrap(0.5, 0.6), 0.6, places=6)

    def test_wrap_positive(self):
        result = angle_unwrap(3.0, -3.0)
        self.assertAlmostEqual(result, 3.0 + (2 * math.pi - 6.0), places=4)

    def test_wrap_negative(self):
        result = angle_unwrap(-3.0, 3.0)
        self.assertTrue(abs(result - (-3.0 - (2 * math.pi - 6.0))) < 0.1)


class TestKalman2D(unittest.TestCase):
    def test_constant_velocity(self):
        k = Kalman2D()
        dt = 1.0 / 30.0
        for i in range(60):
            x = i * 2.0
            y = i * 1.0
            k.predict(dt)
            k.update(x, y)
        sx, sy, svx, svy = k.state
        self.assertAlmostEqual(sx, 118.0, delta=5.0)
        self.assertAlmostEqual(sy, 59.0, delta=3.0)
        self.assertGreater(abs(svx), 10.0)

    def test_reset(self):
        k = Kalman2D()
        k.predict(0.03)
        k.update(100.0, 200.0)
        k.reset()
        self.assertFalse(k.initialized)


class TestAngleKalman(unittest.TestCase):
    def test_constant_rotation(self):
        k = AngleKalman()
        omega_true = 5.0
        dt = 1.0 / 30.0
        for i in range(120):
            theta = omega_true * i * dt
            k.predict(dt)
            k.update(theta % (2 * math.pi))
        self.assertAlmostEqual(k.omega, omega_true, delta=1.0)


if __name__ == "__main__":
    unittest.main()
