"""Entry point. Bootstraps Qt, applies dark style, opens main window."""
from __future__ import annotations

import os
import sys
import signal
import logging

os.environ.setdefault("QT_MAC_WANTS_LAYER", "1")
os.environ.setdefault("OPENCV_VIDEOIO_PRIORITY_MSMF", "0")

from PyQt6.QtWidgets import QApplication

from ui.main_window import MainWindow
from ui.style import apply_dark_style


def _configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


def main() -> int:
    _configure_logging()
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    app = QApplication(sys.argv)
    app.setApplicationName("Roulette Tracker")
    app.setOrganizationName("RouletteTracker")
    apply_dark_style(app)

    window = MainWindow()
    window.show()

    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
