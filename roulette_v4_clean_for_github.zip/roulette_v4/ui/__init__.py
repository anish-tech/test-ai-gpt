"""UI package — PyQt6 widgets for the roulette tracker."""
