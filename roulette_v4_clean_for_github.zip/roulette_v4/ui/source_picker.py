"""Source picker dialog: choose capture method and screen region."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import Qt, QRect
from PyQt6.QtGui import QIntValidator
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QPushButton, QLineEdit, QGroupBox, QFormLayout,
    QFileDialog, QSpinBox, QDialogButtonBox,
)

from config.defaults import Config
from core.capture import list_monitors

log = logging.getLogger(__name__)


class SourcePickerDialog(QDialog):
    """Lets the user pick a capture source and configure region."""

    def __init__(self, cfg: Config, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Capture Source")
        self.setMinimumWidth(400)
        self._cfg = cfg
        self._result_source: Optional[str] = None
        self._result_region: tuple[int, int, int, int] = cfg.region
        self._result_monitor: int = cfg.monitor_index
        self._result_file: str = ""
        self._result_cam_idx: int = 0

        layout = QVBoxLayout(self)

        # Source type
        src_group = QGroupBox("Source Type")
        src_lay = QFormLayout(src_group)
        self._src_combo = QComboBox()
        self._src_combo.addItems(["Screen Region", "Virtual Camera (OBS)", "Video File"])
        idx_map = {"screen_region": 0, "virtual_camera": 1, "video_file": 2}
        self._src_combo.setCurrentIndex(idx_map.get(cfg.capture_source, 0))
        self._src_combo.currentIndexChanged.connect(self._on_source_changed)
        src_lay.addRow("Type:", self._src_combo)
        layout.addWidget(src_group)

        # Region settings
        self._region_group = QGroupBox("Screen Region")
        rlay = QFormLayout(self._region_group)

        monitors = list_monitors()
        self._mon_combo = QComboBox()
        for i, m in enumerate(monitors):
            if i == 0:
                self._mon_combo.addItem(f"All monitors ({m['width']}x{m['height']})")
            else:
                self._mon_combo.addItem(f"Monitor {i} ({m['width']}x{m['height']})")
        if cfg.monitor_index < len(monitors):
            self._mon_combo.setCurrentIndex(cfg.monitor_index)
        rlay.addRow("Monitor:", self._mon_combo)

        self._x_spin = QSpinBox()
        self._x_spin.setRange(0, 9999)
        self._x_spin.setValue(cfg.region[0])
        rlay.addRow("X:", self._x_spin)

        self._y_spin = QSpinBox()
        self._y_spin.setRange(0, 9999)
        self._y_spin.setValue(cfg.region[1])
        rlay.addRow("Y:", self._y_spin)

        self._w_spin = QSpinBox()
        self._w_spin.setRange(100, 4096)
        self._w_spin.setValue(cfg.region[2])
        rlay.addRow("Width:", self._w_spin)

        self._h_spin = QSpinBox()
        self._h_spin.setRange(100, 4096)
        self._h_spin.setValue(cfg.region[3])
        rlay.addRow("Height:", self._h_spin)

        layout.addWidget(self._region_group)

        # Camera settings
        self._cam_group = QGroupBox("Camera")
        clay = QFormLayout(self._cam_group)
        self._cam_spin = QSpinBox()
        self._cam_spin.setRange(0, 10)
        self._cam_spin.setValue(0)
        clay.addRow("Device index:", self._cam_spin)
        self._cam_group.hide()
        layout.addWidget(self._cam_group)

        # File settings
        self._file_group = QGroupBox("Video File")
        flay = QHBoxLayout(self._file_group)
        self._file_edit = QLineEdit()
        self._file_edit.setPlaceholderText("Select a video file…")
        flay.addWidget(self._file_edit)
        browse_btn = QPushButton("Browse…")
        browse_btn.clicked.connect(self._browse_file)
        flay.addWidget(browse_btn)
        self._file_group.hide()
        layout.addWidget(self._file_group)

        # FPS
        fps_group = QGroupBox("Performance")
        fpslay = QFormLayout(fps_group)
        self._fps_spin = QSpinBox()
        self._fps_spin.setRange(10, 60)
        self._fps_spin.setValue(cfg.target_fps)
        fpslay.addRow("Target FPS:", self._fps_spin)
        layout.addWidget(fps_group)

        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._on_source_changed(self._src_combo.currentIndex())

    def _on_source_changed(self, idx: int) -> None:
        self._region_group.setVisible(idx == 0)
        self._cam_group.setVisible(idx == 1)
        self._file_group.setVisible(idx == 2)

    def _browse_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Video", "", "Video Files (*.mp4 *.avi *.mkv *.mov);;All Files (*)"
        )
        if path:
            self._file_edit.setText(path)

    def _accept(self) -> None:
        idx = self._src_combo.currentIndex()
        if idx == 0:
            self._result_source = "screen_region"
            self._result_region = (
                self._x_spin.value(), self._y_spin.value(),
                self._w_spin.value(), self._h_spin.value(),
            )
            self._result_monitor = self._mon_combo.currentIndex()
        elif idx == 1:
            self._result_source = "virtual_camera"
            self._result_cam_idx = self._cam_spin.value()
        else:
            self._result_source = "video_file"
            self._result_file = self._file_edit.text()
        self.accept()

    def apply_to_config(self, cfg: Config) -> Config:
        if self._result_source:
            cfg.capture_source = self._result_source
        cfg.region = self._result_region
        cfg.monitor_index = self._result_monitor
        cfg.target_fps = self._fps_spin.value()
        return cfg

    @property
    def video_file_path(self) -> str:
        return self._result_file

    @property
    def camera_index(self) -> int:
        return self._result_cam_idx
