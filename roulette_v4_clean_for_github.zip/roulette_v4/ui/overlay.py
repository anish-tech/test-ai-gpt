"""Overlay V4 — countdown-aware, locked prediction display."""
from __future__ import annotations

import math
from typing import Optional

import cv2
import numpy as np
from PyQt6.QtCore import Qt, QRect, QPointF
from PyQt6.QtGui import QImage, QPainter, QColor, QPen, QFont, QBrush, QPixmap
from PyQt6.QtWidgets import QWidget

from config.wheel_layouts import WheelLayout
from core.pipeline import PipelineResult


class OverlayWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(320, 320)
        self._pixmap: Optional[QPixmap] = None
        self._result: Optional[PipelineResult] = None
        self._layout: Optional[WheelLayout] = None
        self._show_heatmap = True

    def set_layout(self, layout): self._layout = layout
    def set_show_heatmap(self, val): self._show_heatmap = val

    def set_frame(self, bgr_image):
        h, w = bgr_image.shape[:2]
        rgb = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2RGB)
        qimg = QImage(rgb.data, w, h, 3 * w, QImage.Format.Format_RGB888)
        self._pixmap = QPixmap.fromImage(qimg)
        self.update()

    def update_result(self, result):
        self._result = result

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor("#11111b"))

        if self._pixmap is None:
            p.setPen(QColor("#585b70")); p.setFont(QFont("Menlo", 14))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "No signal")
            p.end(); return

        ww, wh = self.width(), self.height()
        iw, ih = self._pixmap.width(), self._pixmap.height()
        sc = min(ww / max(1, iw), wh / max(1, ih))
        dw, dh = int(iw * sc), int(ih * sc)
        ox, oy = (ww - dw) // 2, (wh - dh) // 2
        p.drawPixmap(QRect(ox, oy, dw, dh), self._pixmap)

        r = self._result
        if r is None: p.end(); return

        if r.wheel is not None:
            cx = ox + r.wheel.cx * sc
            cy = oy + r.wheel.cy * sc
            rad = r.wheel.radius * sc

            # Wheel circle
            p.setPen(QPen(QColor(0, 220, 180, 90), 1.5, Qt.PenStyle.DashLine))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(QPointF(cx, cy), rad, rad)

            # Ball trail
            trail = r.ball_trail[-25:] if r.ball_trail else []
            if len(trail) > 1:
                n = len(trail)
                for i in range(1, n):
                    alpha = int(30 + 200 * (i / n))
                    p.setPen(QPen(QColor(249, 226, 175, alpha), max(1, int(2.5 * i / n))))
                    x0, y0 = ox + trail[i-1][0] * sc, oy + trail[i-1][1] * sc
                    x1, y1 = ox + trail[i][0] * sc, oy + trail[i][1] * sc
                    p.drawLine(QPointF(x0, y0), QPointF(x1, y1))

            # Ball marker — solid dot with glow
            if r.ball_xy is not None:
                bx, by = ox + r.ball_xy[0] * sc, oy + r.ball_xy[1] * sc
                br = max(4, int(rad * 0.03))
                if r.ball_detected:
                    # Glow
                    p.setPen(Qt.PenStyle.NoPen)
                    p.setBrush(QBrush(QColor(249, 226, 175, 40)))
                    p.drawEllipse(QPointF(bx, by), br * 2.5, br * 2.5)
                    # Solid ball
                    p.setBrush(QBrush(QColor(249, 226, 175, 220)))
                    p.drawEllipse(QPointF(bx, by), br, br)
                else:
                    # Ghost position (predicted)
                    p.setPen(QPen(QColor(249, 226, 175, 60), 1, Qt.PenStyle.DotLine))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawEllipse(QPointF(bx, by), br, br)

            # Prediction arc
            pred = r.prediction
            if pred and self._layout and pred.confidence > 0.03 and pred.spin_phase != "no_spin":
                np_ = self._layout.n_pockets
                arc_d = 360.0 / np_
                cd = (pred.landing_index * arc_d) % 360
                spread = arc_d * 7
                sd = cd - spread / 2
                if pred.prediction_locked:
                    ac = QColor(166, 227, 161, 220)  # bright green = locked
                elif pred.confidence > 0.4:
                    ac = QColor(166, 227, 161, 150)
                elif pred.confidence > 0.2:
                    ac = QColor(249, 226, 175, 130)
                else:
                    ac = QColor(243, 139, 168, 90)
                pen_w = 4 if pred.prediction_locked else 2.5
                p.setPen(QPen(ac, pen_w))
                ar = rad * 0.92
                p.drawArc(int(cx - ar), int(cy - ar), int(2*ar), int(2*ar),
                          int(-sd * 16), int(-spread * 16))

            # Motion energy bar
            bw_, bh_ = 5, 40
            bxs = ox + dw - 14; bys = oy + dh - 50
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(30, 30, 40, 120))
            p.drawRect(int(bxs), int(bys), bw_, bh_)
            fh = max(1, int(bh_ * min(1, r.motion_energy / 25)))
            p.setBrush(QColor("#a6e3a1") if r.motion_spinning else QColor("#45475a"))
            p.drawRect(int(bxs), int(bys + bh_ - fh), bw_, fh)

        # Countdown indicator (top right of video)
        if r.countdown_state != "unknown":
            p.setFont(QFont("Menlo", 10, QFont.Weight.Bold))
            if r.betting_open:
                txt = "BET OPEN"
                col = QColor("#a6e3a1")
                if r.countdown_secs > 0:
                    txt += f" {r.countdown_secs:.0f}s"
            else:
                txt = "BETS CLOSED"
                col = QColor("#f38ba8")
            p.setPen(QColor(0, 0, 0, 180))
            p.drawText(int(ox + dw - 110), int(oy + 18), txt)
            p.setPen(col)
            p.drawText(int(ox + dw - 111), int(oy + 17), txt)

        # Locked prediction badge
        pred = r.prediction
        if pred and pred.prediction_locked and pred.spin_phase != "no_spin":
            p.setFont(QFont("Menlo", 9, QFont.Weight.Bold))
            p.setPen(QColor(0, 0, 0, 180))
            p.drawText(int(ox + 7), int(oy + dh - 8), "🔒 LOCKED")
            p.setPen(QColor("#a6e3a1"))
            p.drawText(int(ox + 6), int(oy + dh - 9), "🔒 LOCKED")

        # HUD
        p.setFont(QFont("Menlo", 9))
        yt = oy + 14
        lines = []
        if r.wheel is not None:
            lines.append(f"W:{abs(r.wheel_omega):.1f} B:{abs(r.ball_omega):.1f}")
        lines.append(f"{'▶SPIN' if r.motion_spinning else '⏸idle'} E:{r.motion_energy:.0f}")
        if pred and pred.confidence > 0.03:
            disp = self._layout.display(pred.landing_number) if self._layout else str(pred.landing_number)
            lines.append(f"→{disp} {pred.confidence:.0%} [{pred.strategy[:3]}]")
        for line in lines:
            p.setPen(QColor(0, 0, 0, 140)); p.drawText(int(ox + 7), int(yt + 1), line)
            p.setPen(QColor("#cdd6f4")); p.drawText(int(ox + 6), int(yt), line)
            yt += 14

        p.end()
