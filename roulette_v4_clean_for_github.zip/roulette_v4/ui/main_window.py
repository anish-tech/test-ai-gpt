"""Main window V4 — countdown-aware, smooth display."""
from __future__ import annotations

import logging
from typing import Optional

from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt6.QtGui import QFont, QIntValidator
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
    QPushButton, QLabel, QComboBox, QCheckBox, QSplitter, QStatusBar,
    QLineEdit, QGridLayout,
)

from config.defaults import Config, load_config, save_config
from config.wheel_layouts import get_layout, RED_NUMBERS
from core.capture import ScreenRegionCapture, VideoFileCapture
from core.capture_worker import CaptureWorker
from core.frame_buffer import FrameBuffer
from core.pipeline import Pipeline, PipelineResult
from ui.overlay import OverlayWidget
from ui.charts import SpeedChart, SectorBarChart
from ui.source_picker import SourcePickerDialog
from ui.calibration_wizard import CalibrationWizard

log = logging.getLogger(__name__)


class _Sig(QObject):
    result_ready = pyqtSignal(object)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Roulette Tracker V4")
        self.setMinimumSize(1200, 750)
        self._cfg = load_config()
        self._layout_obj = get_layout(self._cfg.layout)
        self._buffer: Optional[FrameBuffer] = None
        self._capture: Optional[CaptureWorker] = None
        self._pipeline: Optional[Pipeline] = None
        self._sig = _Sig()
        self._sig.result_ready.connect(self._on_processing_result)
        self._result_count = 0
        self._build_ui()
        self._status_timer = QTimer(self); self._status_timer.timeout.connect(self._update_status); self._status_timer.start(500)
        self._display_timer = QTimer(self); self._display_timer.timeout.connect(self._display_tick)

    def _build_ui(self):
        central = QWidget(); self.setCentralWidget(central)
        top = QHBoxLayout(central); top.setContentsMargins(4,4,4,4)
        splitter = QSplitter(Qt.Orientation.Horizontal); top.addWidget(splitter)

        left = QWidget(); lv = QVBoxLayout(left); lv.setContentsMargins(0,0,0,0)
        self._overlay = OverlayWidget(); self._overlay.set_layout(self._layout_obj)
        lv.addWidget(self._overlay, 5)
        self._speed_chart = SpeedChart(); lv.addWidget(self._speed_chart, 1)
        self._sector_chart = SectorBarChart(); self._sector_chart.set_layout(self._layout_obj)
        lv.addWidget(self._sector_chart, 1)
        splitter.addWidget(left)

        right = QWidget(); right.setMaximumWidth(370); right.setMinimumWidth(280)
        rv = QVBoxLayout(right); rv.setContentsMargins(0,0,0,0)

        # Prediction
        pb = QGroupBox("Prediction"); pv = QVBoxLayout(pb)
        self._pred_number = QLabel("—"); self._pred_number.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._pred_number.setFont(QFont("Menlo", 48, QFont.Weight.Bold))
        self._pred_number.setStyleSheet("color:#585b70;font-size:48px;")
        pv.addWidget(self._pred_number)
        self._pred_lock = QLabel(""); self._pred_lock.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._pred_lock.setFont(QFont("Menlo", 11, QFont.Weight.Bold))
        pv.addWidget(self._pred_lock)
        self._pred_conf = QLabel("Confidence: —"); self._pred_conf.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._pred_conf.setFont(QFont("Menlo", 13)); pv.addWidget(self._pred_conf)
        self._pred_phase = QLabel("Phase: waiting"); self._pred_phase.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._pred_phase.setStyleSheet("color:#a6e3a1;"); pv.addWidget(self._pred_phase)
        self._pred_strategy = QLabel("Strategy: —"); self._pred_strategy.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._pred_strategy.setFont(QFont("Menlo", 9)); self._pred_strategy.setStyleSheet("color:#89b4fa;")
        pv.addWidget(self._pred_strategy)
        self._pred_neighbors = QLabel("Neighbors: —"); self._pred_neighbors.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._pred_neighbors.setFont(QFont("Menlo", 10)); pv.addWidget(self._pred_neighbors)
        self._pred_top5 = QLabel(""); self._pred_top5.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._pred_top5.setFont(QFont("Menlo", 9)); self._pred_top5.setStyleSheet("color:#cdd6f4;")
        pv.addWidget(self._pred_top5)
        self._pred_countdown = QLabel(""); self._pred_countdown.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._pred_countdown.setFont(QFont("Menlo", 11, QFont.Weight.Bold))
        pv.addWidget(self._pred_countdown)
        rv.addWidget(pb)

        # Result entry
        rb = QGroupBox("Record Results"); rl = QVBoxLayout(rb)
        rl.addWidget(QLabel("Enter result after each spin:"))
        er = QHBoxLayout()
        self._result_input = QLineEdit(); self._result_input.setPlaceholderText("0-36")
        self._result_input.setValidator(QIntValidator(0, 36)); self._result_input.setMaximumWidth(80)
        self._result_input.setFont(QFont("Menlo", 14)); self._result_input.returnPressed.connect(self._submit_result)
        er.addWidget(self._result_input)
        bs = QPushButton("Record"); bs.setStyleSheet("background-color:#89b4fa;color:#1e1e2e;font-weight:bold;padding:6px;")
        bs.clicked.connect(self._submit_result); er.addWidget(bs)
        rl.addLayout(er)
        qg = QGridLayout()
        for i in range(37):
            b = QPushButton(str(i)); b.setFixedSize(32, 26); b.setFont(QFont("Menlo", 8))
            if i == 0: b.setStyleSheet("background-color:#a6e3a1;color:#1e1e2e;")
            elif i in RED_NUMBERS: b.setStyleSheet("background-color:#f38ba8;color:#1e1e2e;")
            else: b.setStyleSheet("background-color:#45475a;color:#cdd6f4;")
            b.clicked.connect(lambda c, n=i: self._record_number(n))
            qg.addWidget(b, i // 10, i % 10)
        rl.addLayout(qg)
        self._lbl_rec = QLabel("Results: 0"); self._lbl_rec.setFont(QFont("Menlo", 9))
        rl.addWidget(self._lbl_rec); rv.addWidget(rb)

        # Controls
        cb = QGroupBox("Controls"); cl = QVBoxLayout(cb)
        r1 = QHBoxLayout()
        self._btn_start = QPushButton("Start"); self._btn_start.setStyleSheet("background-color:#a6e3a1;color:#1e1e2e;font-weight:bold;padding:6px;")
        self._btn_start.clicked.connect(self._start); r1.addWidget(self._btn_start)
        self._btn_stop = QPushButton("Stop"); self._btn_stop.setStyleSheet("background-color:#f38ba8;color:#1e1e2e;font-weight:bold;padding:6px;")
        self._btn_stop.clicked.connect(self._stop); r1.addWidget(self._btn_stop)
        cl.addLayout(r1)
        r2 = QHBoxLayout()
        QPushButton_src = QPushButton("Source…"); QPushButton_src.clicked.connect(self._pick_source); r2.addWidget(QPushButton_src)
        QPushButton_cal = QPushButton("Calibrate…"); QPushButton_cal.clicked.connect(self._calibrate); r2.addWidget(QPushButton_cal)
        cl.addLayout(r2)
        br = QPushButton("Reset Spin"); br.clicked.connect(self._reset_spin); cl.addWidget(br)
        rv.addWidget(cb)

        # Settings
        sb = QGroupBox("Settings"); sl = QVBoxLayout(sb)
        r3 = QHBoxLayout(); r3.addWidget(QLabel("Layout:"))
        self._combo = QComboBox(); self._combo.addItems(["European", "American"])
        self._combo.setCurrentText(self._cfg.layout.title()); self._combo.currentTextChanged.connect(self._layout_changed)
        r3.addWidget(self._combo); sl.addLayout(r3)
        ch = QCheckBox("Show heatmap"); ch.setChecked(self._cfg.show_heatmap)
        ch.toggled.connect(lambda v: self._overlay.set_show_heatmap(v)); sl.addWidget(ch)
        rv.addWidget(sb)

        # Hot sectors
        hb = QGroupBox("Hot Sectors"); hl = QVBoxLayout(hb)
        self._lbl_hot = QLabel("Record results to see bias"); self._lbl_hot.setFont(QFont("Menlo", 9))
        self._lbl_hot.setWordWrap(True); hl.addWidget(self._lbl_hot); rv.addWidget(hb)

        rv.addStretch(); splitter.addWidget(right); splitter.setSizes([750, 370])
        stb = QStatusBar(); self.setStatusBar(stb)
        self._lbl_status = QLabel("Ready"); self._lbl_status.setStyleSheet("color:#a6e3a1;"); stb.addWidget(self._lbl_status)
        self._lbl_fps = QLabel(""); stb.addPermanentWidget(self._lbl_fps)

    def _display_tick(self):
        if self._buffer is None: return
        frame = self._buffer.latest_display()
        if frame is not None: self._overlay.set_frame(frame.image)

    def _on_processing_result(self, result: PipelineResult):
        self._overlay.update_result(result)
        self._speed_chart.push(result.wheel_omega, result.ball_omega, result.motion_energy)
        pred = result.prediction
        num = pred.landing_number
        disp = self._layout_obj.display(num)
        self._pred_number.setText(disp)
        if self._layout_obj.is_green(num): self._pred_number.setStyleSheet("color:#a6e3a1;font-size:48px;")
        elif self._layout_obj.is_red(num): self._pred_number.setStyleSheet("color:#f38ba8;font-size:48px;")
        else: self._pred_number.setStyleSheet("color:#cdd6f4;font-size:48px;")

        # Lock indicator
        if pred.prediction_locked:
            self._pred_lock.setText("🔒 PREDICTION LOCKED")
            self._pred_lock.setStyleSheet("color:#a6e3a1;background-color:#1e3a1e;padding:4px;border-radius:4px;")
        elif pred.lock_time_remaining > 0:
            self._pred_lock.setText(f"⏱ Locking in {pred.lock_time_remaining:.0f}s")
            self._pred_lock.setStyleSheet("color:#f9e2af;")
        else:
            self._pred_lock.setText("")

        self._pred_conf.setText(f"Confidence: {pred.confidence:.0%}")
        pc = {"spinning":"#a6e3a1","decaying":"#f9e2af","dropped":"#fab387","no_spin":"#585b70"}.get(pred.spin_phase,"#585b70")
        self._pred_phase.setText(f"Phase: {pred.spin_phase}"); self._pred_phase.setStyleSheet(f"color:{pc};")
        sc = {"visual":"#a6e3a1","sector_bias":"#89b4fa","dealer_sig":"#cba6f7","combined":"#f9e2af","none":"#585b70"}.get(pred.strategy,"#585b70")
        self._pred_strategy.setText(f"Strategy: {pred.strategy}"); self._pred_strategy.setStyleSheet(f"color:{sc};")
        self._pred_neighbors.setText(f"Neighbors: {', '.join(self._layout_obj.display(n) for n in pred.neighbors)}")
        self._pred_top5.setText("Top: " + " ".join(f"{self._layout_obj.display(n)}({p:.0%})" for n, p in pred.top5))

        # Countdown
        if result.countdown_state != "unknown":
            if result.betting_open:
                ct = "🟢 BETTING OPEN"
                if result.countdown_secs > 0: ct += f" ({result.countdown_secs:.0f}s)"
                self._pred_countdown.setStyleSheet("color:#a6e3a1;")
            else:
                ct = "🔴 BETS CLOSED"
                self._pred_countdown.setStyleSheet("color:#f38ba8;")
            self._pred_countdown.setText(ct)
        else:
            self._pred_countdown.setText("")

        self._sector_chart.set_probabilities(pred.probabilities, pred.landing_index)

    def _submit_result(self):
        t = self._result_input.text().strip()
        if t:
            try:
                n = int(t)
                if 0 <= n <= 36: self._record_number(n)
            except ValueError: pass
        self._result_input.clear()

    def _record_number(self, number):
        self._result_count += 1
        if self._pipeline: self._pipeline.record_result(number)
        self._lbl_rec.setText(f"Results: {self._result_count}")
        self._update_hot()

    def _update_hot(self):
        if not self._pipeline: return
        pr = self._pipeline.predictor
        hot = pr.sector_bias.hot_sectors(7)
        if hot:
            txt = "  ".join(f"{self._layout_obj.display(n)} ({p*self._layout_obj.n_pockets*100:.0f}%)" for n,p in hot)
            avg = pr.dealer_sig.avg_gap()
            if avg is not None: txt += f"\nDealer gap: {avg:.1f} pockets"
            self._lbl_hot.setText(txt)

    def _start(self):
        if self._pipeline: return
        self._buffer = FrameBuffer(maxsize=3)
        src = self._cfg.capture_source
        if src == "video_file": source = VideoFileCapture(self._cfg.region[0])
        else: source = ScreenRegionCapture(self._cfg.region, self._cfg.monitor_index)
        self._capture = CaptureWorker(source, self._buffer, self._cfg.target_fps)
        self._pipeline = Pipeline(self._cfg, self._buffer, self._sig.result_ready.emit)
        self._capture.start(); self._pipeline.start()
        self._display_timer.start(33)
        self._lbl_status.setText("Running…"); self._lbl_status.setStyleSheet("color:#a6e3a1;")

    def _stop(self):
        self._display_timer.stop()
        if self._pipeline: self._pipeline.stop(); self._pipeline = None
        if self._capture: self._capture.stop(); self._capture = None
        self._buffer = None
        self._lbl_status.setText("Stopped"); self._lbl_status.setStyleSheet("color:#f38ba8;")

    def _reset_spin(self):
        if self._pipeline: self._pipeline.reset_spin()
        self._speed_chart.clear()

    def _pick_source(self):
        dlg = SourcePickerDialog(self._cfg, self)
        if dlg.exec(): self._cfg = dlg.apply_to_config(self._cfg); save_config(self._cfg)

    def _calibrate(self):
        dlg = CalibrationWizard(self._cfg, self)
        if dlg.exec():
            self._cfg = dlg.apply_to_config(self._cfg); save_config(self._cfg)
            if self._pipeline: self._pipeline.update_zero_angle(self._cfg.zero_angle_deg)

    def _layout_changed(self, text):
        self._cfg.layout = text.lower(); save_config(self._cfg)
        self._layout_obj = get_layout(self._cfg.layout)
        self._overlay.set_layout(self._layout_obj); self._sector_chart.set_layout(self._layout_obj)

    def _update_status(self):
        parts = []
        if self._capture: parts.append(f"Capture: {self._capture.fps():.1f}")
        if self._pipeline: parts.append(f"Process: {self._pipeline.fps():.1f} FPS")
        self._lbl_fps.setText(" | ".join(parts))

    def closeEvent(self, event):
        self._stop(); save_config(self._cfg); event.accept()
