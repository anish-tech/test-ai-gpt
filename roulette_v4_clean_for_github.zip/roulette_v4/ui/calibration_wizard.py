"""Calibration wizard: detect wheel → pick layout → mark zero pocket."""
from __future__ import annotations

import logging
import math
from typing import Optional

import cv2
import numpy as np
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QImage, QPainter, QColor, QPen, QFont, QMouseEvent
from PyQt6.QtWidgets import (
    QWizard, QWizardPage, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QWidget, QMessageBox,
)

from config.defaults import Config
from config.wheel_layouts import get_layout, EUROPEAN, AMERICAN
from core.wheel_detector import WheelDetector

log = logging.getLogger(__name__)


class _ImageWidget(QWidget):
    """Displays a frame and emits click coordinates."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._qimage: Optional[QImage] = None
        self._circle: Optional[tuple[float, float, float]] = None
        self._click_cb = None
        self._scale = 1.0
        self._ox = 0
        self._oy = 0
        self.setMinimumSize(400, 400)

    def set_image(self, bgr: np.ndarray) -> None:
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        self._qimage = QImage(rgb.data, w, h, 3 * w, QImage.Format.Format_RGB888).copy()
        self.update()

    def set_circle(self, cx: float, cy: float, r: float) -> None:
        self._circle = (cx, cy, r)
        self.update()

    def set_click_callback(self, cb) -> None:
        self._click_cb = cb

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#11111b"))
        if self._qimage is None:
            p.end()
            return
        ww, wh = self.width(), self.height()
        iw, ih = self._qimage.width(), self._qimage.height()
        self._scale = min(ww / max(1, iw), wh / max(1, ih))
        dw = int(iw * self._scale)
        dh = int(ih * self._scale)
        self._ox = (ww - dw) // 2
        self._oy = (wh - dh) // 2
        from PyQt6.QtCore import QRect
        p.drawImage(QRect(self._ox, self._oy, dw, dh), self._qimage)
        if self._circle is not None:
            cx, cy, r = self._circle
            sx = self._ox + cx * self._scale
            sy = self._oy + cy * self._scale
            sr = r * self._scale
            p.setPen(QPen(QColor("#a6e3a1"), 2))
            p.drawEllipse(int(sx - sr), int(sy - sr), int(2 * sr), int(2 * sr))
            p.setPen(QPen(QColor("#f9e2af"), 1))
            p.drawLine(int(sx - 8), int(sy), int(sx + 8), int(sy))
            p.drawLine(int(sx), int(sy - 8), int(sx), int(sy + 8))
        p.end()

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if self._click_cb is not None and self._qimage is not None:
            x = (event.position().x() - self._ox) / max(0.001, self._scale)
            y = (event.position().y() - self._oy) / max(0.001, self._scale)
            self._click_cb(x, y)


class _DetectPage(QWizardPage):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setTitle("Step 1: Detect Wheel")
        self.setSubTitle("Grab a frame from the source and detect the wheel circle.")
        layout = QVBoxLayout(self)
        self._img = _ImageWidget()
        layout.addWidget(self._img)
        self._detect_btn = QPushButton("Detect Wheel")
        self._detect_btn.clicked.connect(self._do_detect)
        layout.addWidget(self._detect_btn)
        self._status = QLabel("Click 'Detect Wheel' to find the rim.")
        layout.addWidget(self._status)
        self._frame: Optional[np.ndarray] = None
        self._detection = None

    def set_frame(self, bgr: np.ndarray) -> None:
        self._frame = bgr.copy()
        self._img.set_image(bgr)

    def _do_detect(self) -> None:
        if self._frame is None:
            self._status.setText("No frame available.")
            return
        det = WheelDetector(redetect_every=1)
        result = det.detect(self._frame, force=True)
        if result is None:
            self._status.setText("Detection failed. Try adjusting brightness or crop.")
            return
        self._detection = result
        self._img.set_circle(result.cx, result.cy, result.radius)
        self._status.setText(
            f"Found wheel at ({result.cx:.0f}, {result.cy:.0f}), "
            f"radius {result.radius:.0f}px"
        )
        self.completeChanged.emit()

    def isComplete(self) -> bool:
        return self._detection is not None

    @property
    def detection(self):
        return self._detection


class _LayoutPage(QWizardPage):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setTitle("Step 2: Choose Layout")
        self.setSubTitle("Select the wheel type used at this casino.")
        layout = QVBoxLayout(self)
        self._combo = QComboBox()
        self._combo.addItems(["European (37 pockets, single zero)", "American (38 pockets, double zero)"])
        layout.addWidget(self._combo)
        info = QLabel(
            "European wheels have pockets 0-36.\n"
            "American wheels add a 00 pocket."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

    @property
    def layout_name(self) -> str:
        return "european" if self._combo.currentIndex() == 0 else "american"


class _ZeroPage(QWizardPage):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setTitle("Step 3: Mark Zero Pocket")
        self.setSubTitle("Click on the green zero (0) pocket to align the layout.")
        layout = QVBoxLayout(self)
        self._img = _ImageWidget()
        self._img.set_click_callback(self._on_click)
        layout.addWidget(self._img)
        self._status = QLabel("Click on the visible '0' pocket on the wheel.")
        layout.addWidget(self._status)
        self._zero_angle: Optional[float] = None
        self._center: Optional[tuple[float, float]] = None

    def set_frame_and_center(self, bgr: np.ndarray, cx: float, cy: float, r: float) -> None:
        self._img.set_image(bgr)
        self._img.set_circle(cx, cy, r)
        self._center = (cx, cy)

    def _on_click(self, x: float, y: float) -> None:
        if self._center is None:
            return
        angle = math.atan2(y - self._center[1], x - self._center[0])
        self._zero_angle = angle
        deg = math.degrees(angle) % 360
        self._status.setText(f"Zero marked at {deg:.1f}°")
        self.completeChanged.emit()

    def isComplete(self) -> bool:
        return self._zero_angle is not None

    @property
    def zero_angle_rad(self) -> float:
        return self._zero_angle if self._zero_angle is not None else 0.0


class CalibrationWizard(QWizard):
    """Three-step calibration wizard."""

    def __init__(self, cfg: Config, initial_frame: Optional[np.ndarray] = None, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Calibration Wizard")
        self.setMinimumSize(600, 550)

        self._cfg = cfg
        self._detect_page = _DetectPage()
        self._layout_page = _LayoutPage()
        self._zero_page = _ZeroPage()

        self.addPage(self._detect_page)
        self.addPage(self._layout_page)
        self.addPage(self._zero_page)

        if initial_frame is not None:
            self._detect_page.set_frame(initial_frame)

        self.currentIdChanged.connect(self._on_page_change)

    def _on_page_change(self, page_id: int) -> None:
        if page_id == 2:  # Zero page
            det = self._detect_page.detection
            frame = self._detect_page._frame
            if det is not None and frame is not None:
                self._zero_page.set_frame_and_center(frame, det.cx, det.cy, det.radius)

    def apply_to_config(self, cfg: Config) -> Config:
        cfg.layout = self._layout_page.layout_name
        cfg.zero_angle_deg = math.degrees(self._zero_page.zero_angle_rad) % 360
        return cfg

    def set_frame(self, bgr: np.ndarray) -> None:
        self._detect_page.set_frame(bgr)
