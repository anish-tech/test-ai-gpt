"""Charts V3 — speed chart + sector probability bar chart."""
from __future__ import annotations

from collections import deque
from typing import Optional

import numpy as np
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPainter, QColor, QPen, QFont
from PyQt6.QtWidgets import QWidget

from config.wheel_layouts import WheelLayout


class SpeedChart(QWidget):
    def __init__(self, max_points=150, parent=None):
        super().__init__(parent)
        self.setMinimumSize(300, 90)
        self._max = max_points
        self._wheel: deque[float] = deque(maxlen=max_points)
        self._ball: deque[float] = deque(maxlen=max_points)
        self._energy: deque[float] = deque(maxlen=max_points)

    def push(self, wheel_omega, ball_omega, motion_energy=0):
        self._wheel.append(abs(wheel_omega))
        self._ball.append(abs(ball_omega))
        self._energy.append(motion_energy)
        self.update()

    def clear(self):
        self._wheel.clear()
        self._ball.clear()
        self._energy.clear()
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor("#181825"))

        w, h = self.width(), self.height()
        ml, mb = 36, 18
        pw, ph = w - ml - 6, h - mb - 6

        if len(self._wheel) < 2:
            p.setPen(QColor("#585b70"))
            p.setFont(QFont("Menlo", 10))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Collecting…")
            p.end()
            return

        vals = list(self._wheel) + list(self._ball)
        y_max = max(max(vals), 0.5) * 1.15

        # Grid
        p.setPen(QPen(QColor("#313244"), 1))
        p.drawLine(ml, 4, ml, h - mb)
        p.drawLine(ml, h - mb, w - 4, h - mb)

        p.setFont(QFont("Menlo", 8))
        for frac in (0.0, 0.5, 1.0):
            yy = int(4 + ph * (1 - frac))
            p.setPen(QColor("#6c7086"))
            p.drawText(2, yy + 3, f"{y_max * frac:.0f}")
            if frac > 0:
                p.setPen(QPen(QColor("#313244"), 1, Qt.PenStyle.DotLine))
                p.drawLine(ml + 1, yy, w - 4, yy)

        def draw(data, color, alpha=255):
            n = len(data)
            if n < 2:
                return
            pts = list(data)
            p.setPen(QPen(QColor(color.red(), color.green(), color.blue(), alpha), 1.5))
            for i in range(1, n):
                x0 = ml + int((i - 1) / (self._max - 1) * pw)
                x1 = ml + int(i / (self._max - 1) * pw)
                y0 = 4 + int(ph * (1 - min(pts[i - 1] / y_max, 1)))
                y1 = 4 + int(ph * (1 - min(pts[i] / y_max, 1)))
                p.drawLine(x0, y0, x1, y1)

        draw(self._wheel, QColor("#a6e3a1"))
        draw(self._ball, QColor("#f9e2af"))

        # Motion energy as faint fill
        if self._energy:
            e_max = max(max(self._energy), 1)
            for i in range(len(self._energy)):
                x = ml + int(i / (self._max - 1) * pw)
                eh = int(ph * min(list(self._energy)[i] / e_max, 1) * 0.3)
                p.fillRect(x, h - mb - eh, max(1, int(pw / self._max)), eh,
                           QColor(137, 180, 250, 30))

        p.setFont(QFont("Menlo", 8))
        p.setPen(QColor("#a6e3a1"))
        p.drawText(ml + 6, h - 3, "Wheel")
        p.setPen(QColor("#f9e2af"))
        p.drawText(ml + 60, h - 3, "Ball")
        p.setPen(QColor("#89b4fa"))
        p.drawText(ml + 100, h - 3, "Energy")
        p.end()


class SectorBarChart(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(300, 70)
        self._probs: Optional[np.ndarray] = None
        self._layout: Optional[WheelLayout] = None
        self._highlight = -1

    def set_layout(self, layout):
        self._layout = layout
        self.update()

    def set_probabilities(self, probs, highlight_idx=-1):
        self._probs = probs
        self._highlight = highlight_idx
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor("#181825"))

        if self._probs is None or self._layout is None:
            p.setPen(QColor("#585b70"))
            p.setFont(QFont("Menlo", 10))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "No data yet")
            p.end()
            return

        w, h = self.width(), self.height()
        n = len(self._probs)
        mb = 16
        btw = w - 6
        bw = max(2, btw / n - 1)
        mp = max(float(self._probs.max()), 1e-6)
        bh_max = h - mb - 6

        uniform = 1.0 / n
        for i in range(n):
            prob = float(self._probs[i])
            bh = max(1, int(prob / mp * bh_max))
            x = 3 + int(i * (btw / n))
            y = h - mb - bh
            num = self._layout.index_to_number(i)
            if i == self._highlight:
                c = QColor("#f9e2af")
            elif prob > uniform * 1.5:  # Hot sector
                c = QColor("#f38ba8") if self._layout.is_red(num) else QColor("#a6e3a1")
            elif self._layout.is_green(num):
                c = QColor("#a6e3a1")
            elif self._layout.is_red(num):
                c = QColor("#f38ba8")
            else:
                c = QColor("#585b70")
            p.fillRect(int(x), y, max(2, int(bw)), bh, c)

        # Uniform line
        uni_y = h - mb - int(uniform / mp * bh_max)
        p.setPen(QPen(QColor(255, 255, 255, 40), 1, Qt.PenStyle.DashLine))
        p.drawLine(3, uni_y, w - 3, uni_y)

        # Labels for top 5
        top5 = np.argsort(self._probs)[::-1][:5]
        p.setFont(QFont("Menlo", 7))
        for idx in top5:
            num = self._layout.index_to_number(int(idx))
            x = 3 + int(int(idx) * (btw / n))
            p.setPen(QColor("#cdd6f4"))
            p.drawText(int(x), h - 2, self._layout.display(num))
        p.end()
